#
# (C) COPYRIGHT International Business Machines Corp., 2009, 2020.
# All Rights Reserved * Licensed Materials - Property of IBM

--------------------------------------------------------------------------------
IBM Support Assistant Lite for InfoSphere Information Server Tool, 
version 11.7.1.1 MAR 2020
--------------------------------------------------------------------------------

Description
-----------

The IBM Support Assistant Lite for InfoSphere Information Server Tool (hereafter 
ISA Lite for IS Tool) provides tools that help you resolve problems with an 
existing InfoSphere Information Server installation.  Additional tools verify 
that an existing system is ready to accept installation of IBM InfoSphere 
Information Server.

The ISA Lite for IS Tool is based on the IBM Support Assistant Lite Tool 
framework.  Additional information on this framework, including download, 
installation, and invocation information, is available in the file 
ISALite\readme\README.txt.

A full User's Guide of the ISA Lite for IS Tool is available in the file 
ISALite\doc\UserGuide.pdf.

All current versions of ISA Lite for IS Tool are available for download at 
https://www.ibm.com/support/pages/download-isalite-infosphere-information-server-tool
	
You can always upgrade the current ISALite tool to a newer version. Check the 
download site if a newer version is available for the version of InfoSphere 
Information Server you are using.


Supported Environments
-----------------------

ISA Lite for IS Tool version S11.7.1.1 supports the following versions 
of InfoSphere Information Server, including any Service Packs or RollupPacks of
- 11.3.0 GA
- 11.3.1.0 
- 11.3.1.1
- 11.3.1.2 
- 11.5.0.0
- 11.5.0.1
- 11.5.0.2
- 11.7.0.0
- 11.7.0.1
- 11.7.0.2
- 11.7.1.0
- 11.7.1.1


Supported operating systems, as supported by the different InfoSphere Information Server versions, are:
- Windows (invocation of the ISA Lite for IS Tool as user Administrator is recommended)
    - Windows 7, Windows 8.1, and Windows 10 for InfoSphere Information Server Client Tier only
    - Windows 2008. Windows 2012, Windows 2016 for all InfoSphere Information Server tiers
- Red Hat Enterprise Linux 6
- Red Hat Enterprise Linux 7
- AIX 7.1
- AIX 7.2
- SUSE Linux Enterprise Server 10 
- SUSE Linux Enterprise Server 11 
- SUSE Linux Enterprise Server 12 
- Solaris 10 (IS 11.3.x only)
- zLinux on Z-Systems
invocation of the ISA Lite for IS Tool as user root or sudo-root is recommended on AIX and 
other UNIX systems.

To support InfoSphere Information Server versions 8.5.x through 9.1.2.x, use 
ISA Lite for IS Tool version S9.1.007.7.  

To support zLinux systems with Information Server versions 8.5.x through 9.1.2.x, 
use ISA Lite for IS Tool version S9.1.007.4z.
These versions are available at the download site.

The InfoSphere Information Server Prerequisites Checker option supports IBM DB2 and
Oracle databases.  The Database Collector option supports IBM DB2 database only.  


New in version S11.7.1.1
-------------------------

The following features have been added or significantly modified from previous versions 
- Support of IS 11.3.x - 11.5.0.2 multiple FPs and RUPs
- Support of IS 11.7.x multiple FPs and RUPs



APAR and WORKITEM Fixes 
------------------------

The following APARs are fixed in version S11.7.1.1:
   <none>

The following Enhancements and defect Work Items have been fixed:
    See up to date list on http://www.ibm.com/support/docview.wss?&uid=swg24022700



Documentation
--------------

Additional documentation is available in the ISALite\doc directory.
Documents include:
- IBM Support Assistant Lite for InfoSphere Information Server User Guide

The User Guide includes extensive information about how to download, install,
configure, and use the ISA Lite for IS Tool and its options.  

This documentation is also available at the download site.



Known Issues
-------------

1. The Database Collector tool will only automatically recognize a metadata 
repository created and configured as part of the InfoSphere Information Server 
installation process.  Currently, IBM DB2 is the only database bundled with and 
available for installation during the InfoSphere Information Server installation.

2. The ISA Lite for IS Tool fully supports only English language systems.  The 
options can be run on non-English systems, but output may be missing, incorrect, 
or incomplete.

3. When running on a Windows system, certain domain users are not correctly 
recognized as administrators.  If the domain user is a member of a domain group
which is part of the local Administrators group, but is not listed directly as 
a member of the local Administrators group, the user will not be recognized as 
an administrator.  Add the domain user directly to the local Administrators 
group to avoid this issue.

4. Windows 2008, 2012, 7, 8, 10 have only limited support.  For best results, we 
recommend running the ISA Lite for IS Tool either as the user Administrator or 
by selecting runISALite.bat, right mouse clicking, and using the 'Run as Admin' 
option from the menu displayed.  In console mode, use the runas.exe command to 
invoke the tool as an Administrator.

5. Multiple concurrent users are not supported in this version, but are not 
prevented by the tool.  There are several errors that can happen due to shared 
temporary storage.
