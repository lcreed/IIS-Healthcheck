# (C) COPYRIGHT International Business Machines Corp., 2007
# Reservats tots els drets * Materials sota llic�ncia - Propietat d'IBM

-------------------------------------------------------------
Eina IBM Support Assistant Lite
-------------------------------------------------------------

Descripci�
---------------

L'eina IBM Support Assistant Lite proporciona la recollida de dades autom�tica per als productes d'IBM. L'eina est� preconfigurada per trobar dades importants de diagn�stic en el vostre sistema i copiar-les en un fitxer del col�lector. Un exemple de dades de diagn�stic �s un fitxer d'anotacions generat pel producte d'IBM que cont� un historial detallat de les incid�ncies que es produeixen durant el funcionament del producte. Un fitxer com aquest pot ser �til en la determinaci� de la natura i la causa d'un problema de programari.
Altres exemples de dades de diagn�stic s�n els fitxers d'inicialitzaci�, els fitxer de configuraci�, la versi� del sistema operatiu, l'espai en disc i les connexions de xarxa. L'eina es pot executar en mode de GUI o en mode de consola de l�nia d'ordres.
El mode de consola proporciona el control de l�nia d'ordres dels scripts de recollida de l'IBM Support Assistant Lite. L'eina inclou diverses caracter�stiques per ajudar-vos quan hi interactueu
en mode de consola, incloent-n'hi que permet enregistrar les respostes d'una sessi� de mode de consola en un fitxer i, tot seguit, utilitzar el fitxer
per controlar les execucions posteriors del mateix script de recollida. 

Instal�laci� i �s de l'eina
---------------------------
En la majoria dels casos, la seq��ncia de passos seg�ent us permetr� comen�ar a utilitzar l'eina. Si trobeu problemes o voleu m�s informaci� sobre qualsevol dels passos, podeu
consultar els apartats seg�ents. 

1.	Instal�leu l'eina extraient els fitxers del fitxer d'arxiu que heu generat i transferit del sistema d'entorn de treball.
 - Extraieu l'eina a qualsevol directori que trieu.
 - Consulteu els apartats seg�ents per obtenir informaci� detallada sobre com dur a terme les extraccions. 

2. Executeu l'eina en mode de GUI o mode de consola de l�nia d'ordres. 
 - Seguiu el procediment que es descriu tot seguit per definir la variable d'entorn JAVA_HOME. Un cop fet aix�, podeu executar l'script d'inici.
 - Un cop iniciada l'eina, seguiu les instruccions seg�ents per interactuar-hi mentre duu a terme una recollida. 

Instal�laci� de l'eina
--------------------
En tots els casos, la instal�laci� de l'eina IBM Support Assistant Lite
consisteix simplement a extreure els fitxers del fitxer .zip arxivat que heu
generat i transferit des del sistema de l'entorn de treball. 
Els fitxers es poden extreure a qualsevol ubicaci� del sistema de fitxers que trieu
del sistema on executareu l'eina. Aix� crear� un subdirectori
ISALite al directori de destinaci� .


�s de l'eina
-----------
Independentment de si utilitzeu l'eina IBM Support
Assistant Lite en mode de GUI o en mode de consola de l�nia d'ordres,
el procediment per iniciar-la �s el mateix: s'invoca l'script d'inici corresponent
des d'una l�nia d'ordres. En el cas d'un sistema Windows, aquests scripts d'inici s�n
fitxers de lot. En el cas dels altres entorns, s�n scripts d'int�rpret d'ordres. 

Com que l'eina s'implementa com una aplicaci� Java, cal localitzar Java perqu� l'eina es pugui iniciar. Si Java no est� disponible a la variable PATH, haureu de definir la variable d'entorn JAVA_HOME manualment. L'eina IBM Support Assistant Lite exigeix un JRE amb un nivell 1.4.2 o superior
(1.5 o superior al Windows 7 de 64 bits), per la qual cosa cal que us assegureu que hi ha un JRE
adequat instal�lat al sistema on s'executar� l'eina. Si n'hi ha un, haureu d'executar una ordre
espec�fica del sistema operatiu per definir la variable JAVA_HOME de manera que apunti a aquest JRE.
La JVM i el JDK de Microsoft i gij (GNU libgcj) no s'admeten. 

Per exemple, si en una plataforma Windows teniu instal�lat jre1.4.2 a c:\jre1.4.2, haur�eu d'establir JAVA_HOME mitjan�ant l'ordre seg�ent:

SET JAVA_HOME=c:\jre1.4.2
NOTA: no utilitzeu cometes en el valor de l'ordre SET, encara que el valor tingui car�cters d'espai en blanc.

En una plataforma Linux, AIX, Solaris o iSeries, si teniu instal�lat el JRE a /opt/jre142, haur�eu d'establir JAVA_HOME mitjan�ant l'ordre seg�ent:

export JAVA_HOME=/opt/jre142


Inici de l'eina en mode de GUI Swing
------------------------------------
Caldr� que executeu l'script d'inici seg�ent: 

 - Per a l'entorn Windows, ser� l'script runISALite.bat del directori \ISALite de l'eina.
 - Per als entorns Linux, AIX, HP-UX i Solaris, ser� l'script runISALite.sh del directori /ISALite de l'eina. Assegureu-vos que l'script runISALite.sh tingui perm�s d'execuci�; podeu utilitzar l'ordre seg�ent
per atorgar al fitxer perm�s d'execuci�: chmod 755 runISALite.sh 

El mode de GUI no s'admet als entorns iSeries i zSeries: consulteu l'apartat immediatament posterior
per obtenir informaci� sobre com iniciar l'eina al mode de consola de l�nia d'ordres a l'iSeries i el
zSeries. 

Inici de l'eina en mode de consola de l�nia d'ordres
-----------------------------------------------
Si no hi ha disponible una GUI, l'eina s'hauria d'iniciar en mode de l�nia d'ordres de forma autom�tica. 
Si es prefereix el mode de consola encara que hi hagi una GUI disponible, especifiqueu
"-console" a la l�nia d'ordres.
En alguns casos, no ser� possible determinar que una GUI no est� disponible i
l'eina no s'iniciar�. En aquests casos, caldr� reiniciar l'eina amb
"-console". 

Els fitxers s'escriuen al directori d'instal�laci�
-----------------------------------------------
Per defecte, el directori d'instal�laci� de l'ISA Lite s'utilitza per emmagatzemar els fitxers
creats durant l'execuci�. En alguns sistemes, el directori d'instal�laci� de l'ISA Lite ser�
nom�s de lectura. En aquest cas, utilitzeu el par�metre -useHome. Aquest par�metre far� que els fitxers
temporals s'escriguin al directori temporal del sistema i els fitxers persistents s'escriguin al directori
d'inici de l'usuari. 
	
Interacci� amb l'eina
---------------------------
Tant per al mode de consola de l�nia d'ordres com per al mode de GUI se us demanar� que configureu diversos camps, com ara
el nom del fitxer zip de recollida de dades i qualsevol altra informaci� espec�fica del producte. Despr�s, seleccioneu l'opci� de problema perqu� s'efectu� la recollida de dades. 

Quan l'IBM Support Assistant Lite s'executa en mode de text, no hi ha cap llista de selecci� ni camp d'entrada per a l'entrada de l'usuari.
En comptes, les opcions disponibles es presenten com a llistes numerades on cal entrar el n�mero de selecci� seguit per la tecla Retorn. Els camps d'entrada es transformen en sol�licituds en les quals s'especifica una resposta i es prem la tecla Retorn. En acabar la recollida de dades, la sortida ser� un altre fitxer ZIP que es pot tornar a transferir manualment a la m�quina on estigui instal�lat IBM Support Assistant Workbench. Des d'all�, el fitxer ZIP de sortida es pot enviar al servei de suport d'IBM Support o b� es pot examinar localment, d'igual manera que succeeix amb altres recollides efectuades a IBM Support Assistant Workbench.


Per aturar l'eina del col�lector, escriviu quit en mode de text o feu clic al bot� per sortir en mode de GUI. 

L'eina us sol�licitar� noms de fitxer. A les plataformes Unix, no s'admet l'�s de "~" com a designaci� del directori inicial de l'usuari. Si s'utilitza "~", es referenciar� un subdirectori sota el directori de treball actual amb el nom "~".


*NOTA: llegiu la guia de l'usuari d'IBM Support Assistant per obtenir informaci� m�s detallada.

Determinaci� de la informaci� de versi�
----------------------------------
Per defecte, la versi� de l'eina (i els seus diversos subcomponents) s'imprimeix a la consola des de
la qual s'ha iniciat. Quan s'executa en mode de GUI, la informaci� de versi� es pot trobar utilitzant l'opci�
de men� Ajuda->Quant a.
Si Java no est� disponible o l'aplicaci� Java no es pot iniciar, tamb� podeu obtenir la versi� de l'eina executant
els scripts d'inici amb l'opci� "-version". 

*NOTA: quan s'utilitza l'opci� "-version", els scripts d'inici imprimeixen la informaci� de versi� sense invocar realment l'eina. 

Visualitzaci� del fitxer d'inventari
----------------------
L'ISA Lite pot recollir informaci� d'inventari del sistema actual. La sortida �s un fitxer d'inventari (inventory.xml) que es visualitza millor amb un navegador web.
Si el fitxer d'inventari �s present, es pot visualitzar des de l'opci� Fitxer-->Visualitza l'inventari de la GUI de l'ISA Lite. Al Windows, l'ISA Lite intentar� obrir el fitxer d'inventari amb el navegador
per defecte del sistema. Al Linux, l'ISA Lite intentar� obrir el fitxer d'inventari amb el navegador Firefox i, per tant, el Firefox s'ha d'haver instal�lat i ha de ser a la variable PATH. 

Problemes coneguts
----------------------------------
La instal�laci� de l'ISA Lite no s'ha d'efectuar en un directori que tingui car�cters d'espai en blanc que incloguin espais a les plataformes Solaris. 

La instal�laci� de l'ISA Lite no s'ha d'efectuar en un directori que tingui car�cters de punt ('.') a les plataformes Windows.
