# (C) COPYRIGHT International Business Machines Corp., 2007
# All Rights Reserved * Licenseret materiale - tilh�rer IBM

-------------------------------------------------------------
IBM Support Assistant Lite
-------------------------------------------------------------

Beskrivelse
---------------

V�rkt�jet IBM Support Assistant Lite tilbyder automatisk dataindsamling i forbindelse med IBM-produkter. V�rkt�jet er
forudkonfigureret til at s�ge efter vigtige fejlfindingsdata p� computersystemet og kopiere dem til en indsamlingsfil. Et
eksempel p� fejlfindingsdata er en logfil, der er genereret af IBM-produktet, der indeholder en detaljeret historik over
aktiviteter, der forekommer under udf�relse af produktfunktioner. Filen kan anvendes til at bestemme typen af og �rsagen
til et softwareproblem.
Andre eksempler p� fejlfindingsdata er initialiseringsfiler, konfigurationsfiler, styresystemversion,
diskplads og netv�rksforbindelser.
V�rkt�jet kan udf�res i grafisk tilstand eller i en konsol p� en kommandolinje.
I konsoltilstand kan du ved hj�lp af kommandolinjen styre IBM Support Assistant Lite-indsamlingsscripts. V�rkt�jet indeholder
adskillige funktioner, som kan v�re en hj�lp, n�r du bruger konsoltilstand, herunder en funktion hvor du kan registrere dine
svar fra en session i konsoltilstand i en fil og derefter bruge filen til efterf�lgende udf�relse af det samme indsamlingsscript. 

Installation og brug af v�rkt�jer
---------------------------------
Hvis du f�lger nedenst�ende trin, kan du i de fleste tilf�lde derefter anvende v�rkt�jet. Hvis der opst�r problemer, eller
hvis du vil have flere oplysninger om disse trin, kan du l�se de f�lgende afsnit. 

1. Install�r v�rkt�jet at pakke filerne fra den zip-fil, du har oprettet og overf�rt fra Workbench-systemet, ud.
 - Pak v�rkt�jet ud i et bibliotek, du v�lger.
 - L�s afsnittene nedenfor for at f� oplysninger om, hvordan udpakningen skal udf�res. 

2.	Udf�r v�rkt�jet i grafisk tilstand eller p� kommandolinjen i konsoltilstand. 
 - F�lg den procedure, der er beskrevet nedenfor, for at angive JAVA_HOME-milj�variablen. N�r du har gjort dette, kan
   du derefter udf�rt startscriptet.
 - N�r du har startet v�rkt�jet, skal du f�lge vejledningen nedenfor i forbindelse med udf�relsen af indsamlingen.

Installation af v�rkt�jet
-------------------------
Installation af IBM Support Assistant Lite-v�rkt�jet foreg�r ganske enkelt ved at pakke filerne fra den zip-fil, du har
oprettet og overf�rt fra Workbench-systemet, ud. Filerne kan pakkes ud til et hvilket som helst filsystem, du v�lger p� det
system, hvor v�rkt�jet skal udf�res. Dermed oprettes et ISALite-underbibliotek under m�lbiblioteket.


Brug af v�rkt�j
---------------
Angivelse af JAVA_HOME-milj�variablen
Uanset om du anvender IBM Support Assistant Lite-v�rkt�jet i grafisk tilstand eller p� kommandolinjen i konsoltilstand, skal
der bruges den samme metode til at starte det: Du skal aktivere det relevante startscript fra en kommandolinje. Hvis det er
et Windows-system, er disse startscripts batchfiler. I andre systemmilj�er er det shellscripts. 

Da v�rkt�jet er implementeret som et Java-program, skal Java findes, f�r v�rkt�jet kan starte. Hvis Java ikke er tilg�ngelig
i PATH-angivelsen, skal du angive JAVA_HOME-milj�variablen manuelt.
V�rkt�jet IBM Support Assistant Lite kr�ver en JRE p� niveau 1.4.2 eller nyere (1.5 eller nyere p� Windows 7 64 bit), s� du skal f�rst kontrollere, at der er installeret en passende JRE
p� det system, hvor v�rkt�jet skal k�re. Hvis det er tilf�ldet, skal du udf�re en styresystemspecifik kommando for at angive, at JAVA_HOME-variablen skal pege p� denne
JRE. Microsoft JVM/JDK og gij (GNU libgcj) underst�ttes ikke. 

Hvis du f.eks. p� en Windows-platform har jre1.4.2 installeret p� c:\jre1.4.2, skal du angive JAVA_HOME
ved hj�lp af f�lgende kommando:

SET JAVA_HOME=c:\jre1.4.2
BEM�RK: Du m� ikke bruge anf�rselstegn i SET-kommando-v�rdien, heller ikke selv
om v�rdien har tomme pladser.

P� Linux-, AIX-, Solaris- eller iSeries-platformen g�lder, at hvis du har
JRE installeret i /opt/jre142, skal du angive JAVA_HOME ved brug af
f�lgende kommando:

export JAVA_HOME=/opt/jre142


Start af v�rkt�jet i grafisk Swing-tilstand
-------------------------------------------
Du skal udf�re f�lgende startscript:

- I Windows er det scriptet runISALite.bat i biblioteket \ISALite til v�rkt�jet.
- I Linux, AIX, HP-UX og Solaris er det scriptet runISALite.sh i biblioteket /ISALite til v�rkt�jet. 
- S�rg for, at runISALite-scriptet har udf�relsestilladelse. Du kan bruge f�lgende kommando til at give
  filen udf�relsestilladelse: chmod 755 runISALite.sh.

Den grafiske brugergr�nseflade underst�ttes ikke i iSeries og zSeries: I afsnittet lige efter dette er
der oplysninger om, hvordan v�rkt�jet startes fra kommandolinjen i konsoltilstand i iSeries og zSeries. 

Start af v�rkt�jet i kommandolinjetilstand
-----------------------------------------------
Hvis der ikke er en grafisk brugergr�nseflade tilg�ngelig, starter v�rkt�jet automatisk i kommandolinjetilstand. Hvis du vil benytte konsoltilstand, selvom en grafisk brugergr�nseflade er
tilg�ngelig, skal du skrive "-console" p� kommandolinjen. I nogle tilf�lde kan det ikke fastsl�s, at der ikke er en grafisk brugergr�nseflade
tilg�ngelig, og v�rkt�jet kan ikke starte. I s� fald skal v�rkt�jet genstartes ved hj�lp af "-console".

Filer skrives til installationsbiblioteket
-----------------------------------------------
ISA Lite-installationsbiblioteket bruges som standard til at gemme filer, der oprettes under udf�relsen. P� nogle systemer er
ISA Lite-installationsbiblioteket skrivebeskyttet. I s� fald skal du bruge parameteren -useHome. Denne parameter g�r, at midlertidige filer
skrives til systemets temp-bibliotek, og faste filer skrives til brugerens hjemmebibliotek. 
	
Arbejde med v�rkt�jet
---------------------------
B�de i den grafiske brugergr�nseflade og i konsoltilstand p� kommandolinjen bliver du bedt om at konfigurere en r�kke felter, for eksempel ZIP-filen til dataindsamling og eventuelle
andre produktspecifikke oplysninger. Derefter foretager du valg af problem, og
dataindsamlingen udf�res.

N�r IBM Support Assistant Lite udf�res i teksttilstand, er der ingen valglister eller indtastningsfelter, som brugerne
kan angive oplysninger i.
I stedet pr�senteres de tilg�ngelige valg som nummererede lister, og du skal angive tallet
for dit valg og derefter trykke p� Enter. Inputfelter omdannes til instruktionstekster, hvor du skal angive dit svar
og trykke p� Enter. N�r dataindsamlingen er f�rdig, er outputtet en anden ZIP-fil, som manuelt kan tilbagef�res til den
maskine, som IBM Support Assistant Workbench er installeret p�. Derfra kan ZIP-outputfilen sendes til IBM Support eller
unders�ges lokalt p� samme m�de som andre indsamlinger, der udf�res i IBM Support Assistant Workbench.

Skriv quit i teksttilstand for at stoppe indsamlingsv�rkt�jet, eller klik p� knappen Afbryd i grafisk tilstand.

V�rkt�jet sp�rger om filnavne. Brug af "~" som ben�vnelse af brugerens HOME-bibliotek underst�ttes ikke p�
Unix-platforme. Hvis der angives en "~", henvises der til et underbibliotek under det aktuelle arbejdsbibliotek.

* BEM�RK: Der er flere oplysninger i brugervejledningen til IBM Support Assistant.

Versionsoplysninger
----------------------------------
V�rkt�jets version (og versionen af forskellige underkomponenter) udskrives som standard til den konsol, det blev startet
fra. N�r v�rkt�jet k�rer i grafisk tilstand, kan du ogs� finde versionsoplysningerne vha. menupunktet Hj�lp->Om.
Hvis Java ikke er tilg�ngelig, eller Java-programmet ikke kan starte, kan du ogs� f� oplyst v�rkt�jets versionsnummer
ved at k�re startscriptene med parameteren"-version".

*BEM�RK: N�r du bruger parameteren "-version", udskriver startscriptene versionsoplysningerne uden
at starte v�rkt�jet.

Visning af inventarfil
----------------------
ISA Lite kan indsamle inventaroplysninger for det aktuelle system. Outputtet er en inventarfil (inventory.xml), der bedst kan vises i en webbrowser.
Hvis inventarfilen findes, kan den vises ved hj�lp af menupunktet Fil-->Vis inventar i den grafiske brugergr�nseflade til ISA Lite. P� Windows fors�ger ISA Lite at �bne inventarfilen
i standardbrowseren p� systemet. P� Linux fors�ger ISA Lite at �bne inventarfilen i Firefox-browseren. Firefox skal derfor v�re installeret og findes i PATH. 

Kendte problemer
----------------------------------
ISA Lite m� ikke installeres i et bibliotek, der indeholder blanktegn, herunder
mellemrum, p� Solaris-platforme.

ISA Lite m� ikke installeres til et bibliotek, der indeholder punktummer '.' p� Windows-platforme.
