# (C) COPYRIGHT International Business Machines Corp., 2007
# All Rights Reserved * Licensed Materials - Property of IBM

-------------------------------------------------------------
Tool 'IBM Support Assistant Lite'
-------------------------------------------------------------

Beschreibung
---------------

Das Tool 'IBM Support Assistant Lite' erm�glicht die automatische Erfassung von Daten f�r IBM Produkte. Das Tool ist so vorkonfiguriert, dass es wichtige Diagnosedaten auf Ihrem Computersystem aufsp�rt und in eine Collectordatei kopiert. Ein Beispiel von Diagnosedaten ist eine Protokolldatei, die Ihr IBM Produkt generiert hat und ein detailliertes Verlaufsprotokoll von Ereignissen enth�lt, die w�hrend des Betriebs der Software eintreten. Eine solche Datei kann bei der Ermittlung des Wesens und der Ursache eines Softwareproblems n�tzlich sein.
Initialisierungsdateien, Konfigurationsdateien, die Betriebssystemversion, der Plattenspeicherplatz und die Netzverbindungen sind weitere Beispiele f�r derartige Diagnosedaten.
Das Tool kann im GUI-Modus oder in einem Befehlszeilenkonsolmodus ausgef�hrt werden. 
Der Konsolmodus erm�glicht Ihnen die Steuerung der Erfassungsscripts von IBM Support Assistant Lite
�ber die Befehlszeile.  Das Tool umfasst verschiedene Funktionen, die Sie unterst�tzen, wenn Sie
mit dem Tool im Konsolmodus interagieren. Dazu geh�rt auch eine Funktion zur Aufzeichnung Ihrer
Antworten aus einer Konsolmodussitzung in einer Datei, die Sie anschlie�end zur Steuerung nachfolgender
Ausf�hrungen desselben Erfassungsscripts verwenden k�nnen.  

Installation und Verwendung des Tools
-------------------------------------
In den meisten F�llen k�nnen Sie das Tool in den folgenden Schritten installieren und einsatzbereit
machen.  Wenn Probleme auftreten oder weitere Informationen zu einem dieser Schritte gew�nscht werden,
k�nnen Sie die Abschnitte lesen, die auf diesen Abschnitt folgen.  

1.	Installieren Sie das Tool, indem Sie die Dateien aus dem Archiv extrahieren, das Sie aus dem Workbench-System
generiert und �bertragen haben.
 - Extrahieren Sie das Tool in ein beliebiges Verzeichnis, das Sie ausw�hlen.
 - In den nachfolgenden Abschnitten finden Sie detaillierte Informationen zur Ausf�hrung der Extraktionen.  

2.	F�hren Sie das Tool entweder im GUI-Modus oder im Befehlszeilenkonsolmodus aus.  
 - F�hren Sie die unten beschriebene Prozedur aus, um die Umgebungsvariable JAVA_HOME einzustellen. Anschlie�end
   k�nnen Sie das Startscript ausf�hren.
 - Nach dem Start des Tools befolgen Sie die unten beschriebenen Anweisungen zur Interaktion mit dem Tool w�hrend
   der Ausf�hrung einer Erfassung.

Installation des Tools
----------------------
In allen F�llen besteht die Installation des Tools 'IBM Support Assistant Lite' lediglich darin, die Dateien aus
der ZIP-Archivdatei zu extrahieren, die Sie generiert und vom Workbench-System �bertragen haben. Die Dateien k�nnen
an eine beliebige Dateisystemposition extrahiert werden, die Sie auf dem System ausw�hlen, auf dem das Tool
ausgef�hrt werden soll.    
Durch diesen Vorgang wird ein Unterverzeichnis 'ISALite' unter Ihrem Zielverzeichnis
erstellt.


Verwendung des Tools
--------------------
Einstellen der Umgebungsvariablen JAVA_HOME
Unabh�ngig davon, ob Sie das Tool 'IBM Support Assistant Lite' im GUI-Modus oder im Befehlszeilenkonsolmodus verwenden
wollen, verwenden Sie zum Starten des Tools dieselbe Prozedur: Sie rufen das entsprechende Startscript �ber eine
Befehlszeile auf.  Bei einem Windows-System sind diese Startscripts Batchdateien.  In anderen Umgebungen sind sie
Shell-Scripts.  

Da das Tool als Java-Anwendung implementiert ist, muss Java auffindbar sein, bevor das Tool gestartet werden kann. Wenn Java in der Variablen PATH nicht verf�gbar ist, m�ssen Sie die Umgebungsvariable JAVA_HOME manuell festlegen.  
Das Tool 'IBM Support Assistant Lite' erfordert eine Java SE Runtime Environment (JRE) der Version 1.4.2 oder h�her (bzw. der Version 1.5 oder h�her bei Windows 7 64-Bit). Daher m�ssen Sie zun�chst sicherstellen, dass eine entsprechende JRE auf dem System installiert ist, auf dem das Tool ausgef�hrt werden soll. Ist eine solche JRE vorhanden, m�ssen Sie mithilfe eines betriebssystemspezifischen
Befehls die Variable JAVA_HOME so definieren, dass sie auf diese JRE verweist. Die JVM/JDK von Microsoft sowie gij ('GNU libgcj') werden nicht unterst�tzt.

Wenn zum Beispiel auf einer Windows-Plattform die JRE 'jre1.4.2' im Verzeichnis
'c:\jre1.4.2' installiert ist, m�ssten Sie die Variable mit folgendem Befehl festlegen:

SET JAVA_HOME=c:\jre1.4.2
NOTE: Verzichten Sie bei der Angabe des Werts f�r den Befehl SET auf die Verwendung von hochgestellten Anf�hrungszeichen, selbst wenn der Wert Leerzeichen enth�lt.

Auf einer Linux-, AIX-, Solaris- oder iSeries-Plattform m�ssen Sie JAVA-HOME mit folgendem Befehl festlegen, wenn die JRE im Verzeichnis /opt/jre142 installiert ist:

export JAVA_HOME=/opt/jre142


Tool im Swing-GUI-Modus starten
------------------------------------
Hierzu m�ssen Sie das folgende Startscript ausf�hren:

- F�r Windows-Umgebungen ist das Script 'runISALite.bat' im Verzeichnis '\ISALite' des Tools verf�gbar.
- F�r die Linux-, AIX-, HP-UX- und Solaris-Umgebungen ist das Script 'runISALite.sh' im Verzeichnis '/ISALite' des
  Tools verf�gbar. Stellen Sie sicher, dass das Script 'runISALite.sh' die Ausf�hrungsberechtigung hat. Mit dem folgenden Befehl k�nnen Sie der Datei die
Ausf�hrungsberechtigung erteilen: chmod 755 runISALite.sh

Der GUI-Modus wird im iSeries- und zSeries-Umgebungen nicht unterst�tzt. Der Abschnitt, der direkt auf den vorliegenden folgt, enth�lt Informationen dazu, wie das Tool unter iSeries und zSeries im Befehlszeilenkonsolmodus gestartet wird.

Tool im Befehlszeilenkonsolmodus starten
-----------------------------------------------
Wenn keine grafische Benutzerschnittstelle (GUI) verf�gbar ist, sollte das Tool automatisch im Befehlszeilenmodus starten. Wird der Konsolmodus gew�nscht, obwohl eine grafische Benutzerschnittstelle verf�gbar ist, geben Sie in der Befehlszeile die Option "-console" an. In manchen F�llen kann nicht festgestellt werden, dass bzw. ob keine grafische Benutzerschnittstelle verf�gbar ist, und das Tool wird dementsprechend nicht gestartet. In diesen F�llen muss das Tool mit "-console" neu gestartet werden.
Dateien werden in das Installationsverzeichnis geschrieben.-----------------------------------------------
Standardm��ig wird das Installationsverzeichnis von ISA Lite zum Speichern von Dateien verwendet, die w�hrend der Ausf�hrung erstellt wurden. Auf manchen Systemen ist das Installationsverzeichnis von ISA Lite schreibgesch�tzt. In diesem Fall m�ssen Sie den Parameter '-useHome' verwenden. Dieser Parameter bewirkt, dass tempor�re Dateien in das tempor�re Verzeichnis des Systems und als persistent definierte Dateien in das Ausgangsverzeichnis des Benutzers geschrieben werden. 
	
Mit dem Tool interagieren
---------------------------
Sowohl im GUI-Modus als auch im Befehlszeilenkonsolmodus werden Sie aufgefordert, Werte f�r verschiedene Felder anzugeben, wie zum Beispiel den Namen der Ausgabe-ZIP-Datei f�r die Datenerfassung und andere produktspezifische Informationen. Danach w�hlen Sie die Problem-/Fehleroption aus und die Datenerfassung wird ausgef�hrt.

Wenn IBM Support Assistant Lite im Textmodus ausgef�hrt wird, sind keine Auswahllisten oder Eingabefelder f�r
Benutzereingaben verf�gbar. 
Stattdessen werden die verf�gbaren Auswahlm�glichkeiten in Form von nummerierten
Listen angezeigt. Um eine Option auszuw�hlen, geben Sie die Nummer f�r die entsprechende Auswahlm�glichkeit ein
und dr�cken anschlie�end die Eingabetaste. Eingabefelder werden in Eingabeaufforderungen umgesetzt, in die Sie
Ihre Antwort eingeben und anschlie�end die Eingabetaste dr�cken. Die Ausgabe nach Abschluss der Datenerfassung
erfolgt in Form einer weiteren ZIP-Datei, die manuell auf das System zur�ck�bertragen werden kann, auf dem IBM
Support Assistant Workbench installiert ist. Von dort kann die Ausgabe-ZIP-Datei an die IBM Unterst�tzungsfunktion
gesendet werden oder - wie andere Erfassungen, die in IBM Support Assistant Workbench ausgef�hrt werden - lokal
untersucht werden.

Zum Stoppen des Collector-Tools geben Sie den Befehl 'quit' im Textmodus ein oder klicken im GUI-Modus auf die
Schaltfl�che 'Beenden'.

Das Tool fordert zur Angabe von Dateinamen auf. Auf UNIX-Plattformen wird die Verwendung von "~" als Bezeichnung f�r das Ausgangsverzeichnis (HOME) des Benutzers nicht unterst�tzt. Wird "~" verwendet, so wird ein Unterverzeichnis unter dem gegenw�rtigen Arbeitsverzeichnis namens "~" referenziert.
*HINWEIS: Weitere detaillierte Informationen finden Sie im Benutzerhandbuch zu IBM Support Assistant.

Versionsinformationen ermitteln
----------------------------------
Standardm��ig wird die Version des Tools (und seiner diversen Unterkomponenten) auf der Konsole ausgegeben, auf der es gestartet wurde. Wenn die Ausf�hrung im GUI-Modus erfolgt, so k�nnen die Versionsinformationen auch im Hilfemen� mit der Option f�r die Produktinformationen abgefragt werden.
Ist Java nicht verf�gbar oder sollte die Java-Anwendung nicht gestartet werden k�nnen, k�nnen Sie die Version des Tools auch erfahren, indem Sie die Startscripts mit der Option "-version" ausf�hren.
*HINWEIS: Bei Verwendung der Option "-version" geben die Startscripts die Versionsinformationen aus, ohne dass jedoch das Tool tats�chlich aufgerufen wird.

Inventardatei anzeigen
----------------------
ISA Lite kann Inventarinformationen des aktuellen Systems erfassen. Die Ausgabe erfolgt in Form einer Inventardatei (inventory.xml), die am besten mit einem Web-Browser angezeigt wird.
Wenn die Inventardatei vorhanden ist, kann sie mit den Men�optionen 'Datei-->Inventar anzeigen' der grafische Benutzerschnittstelle von ISA Lite angezeigt werden. Unter Windows versucht ISA Lite, die Inventardatei im Standardbrowser des Systems zu �ffnen. Auf Linux versucht ISA Lite, die Inventardatei im Browser Firefox zu �ffnen. Daher muss Firefox installiert und in PATH vorhanden sein.
Bekannte Probleme
----------------------------------
Auf Solaris-Plattformen sollte die Installation von ISA Lite nicht in Verzeichnisse erfolgen, deren Namen Leerzeichen enthalten.

Auf Windows-Plattformen sollte die Installation von ISA Lite nicht in Verzeichnisse ausgef�hrt werden, deren Namen einen oder mehrere Punkte ('.') enthalten.
