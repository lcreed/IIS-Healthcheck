# (C) COPYRIGHT International Business Machines Corp., 2007
# Reservados todos los derechos * Materiales bajo licencia - Propiedad de IBM

-------------------------------------------------------------
Herramienta IBM Support Assistant Lite
-------------------------------------------------------------

Descripci�n
---------------

La herramienta IBM Support Assistant Lite proporciona una recogida de datos autom�tica para los productos de IBM. La herramienta est� preconfigurada para localizar
datos de diagn�stico importantes en el sistema y copiarlos en un archivo de Colector. Un ejemplo de datos de diagn�stico es un archivo de anotaciones generado por el producto IBM
que contenga un historial detallado de los eventos ocurridos durante la operaci�n del producto. Un archivo de este tipo puede ser de utilidad para determinar la naturaleza y la causa de un problema de software.
Otros ejemplos de datos de diagn�stico son los archivos de inicializaci�n, los archivos de configuraci�n, la versi�n del sistema operativo, el espacio de disco y las conexiones de red. La herramienta se puede ejecutar en modalidad de GUI o en una modalidad de consola de l�nea de mandatos.
La modalidad de consola le proporciona un control de l�nea de mandatos de los scripts de recogida de IBM Support Assistant Lite. La herramienta incluye varias caracter�sticas para ayudarle cuando interact�e con ella en la modalidad de consola, que incluye una que le permite registrar las respuestas de una sesi�n de modalidad de consola en un archivo y, a continuaci�n, utilizar el archivo para realizar ejecuciones posteriores del mismo script de recogida. 

Instalaci�n y utilizaci�n de la herramienta
---------------------------
En la mayor�a de los casos, la siguiente secuencia de pasos le guiar� a trav�s del inicio y la ejecuci�n de la herramienta. Si se experimenta problemas, o si desea m�s informaci�n sobre cualquiera de estos pasos, puede hacer referencia a las secciones siguientes que siguen a �sta. 

1.	Instale la herramienta extrayendo los archivos del archivo de archivado que ha generado y transferido desde el sistema del entorno de trabajo.
 - Extraiga la herramienta en cualquier directorio de su elecci�n.
 - Consulte las secciones siguientes para obtener detalles sobre c�mo realizar las extracciones.  

2.	Ejecute la herramienta en la modalidad de GUI o en la modalidad de consola de l�nea de mandatos.  
 - Siga el procedimiento descrito a continuaci�n para definir la variable de entorno JAVA_HOME. Una vez haya hecho esto, podr� ejecutar el script de lanzamiento. 
 - Una vez que haya iniciado la herramienta, siga las instrucciones siguientes para interactuar con �sta cuando realiza una recogida de datos. 

Instalaci�n de la herramienta
--------------------
En todos los casos, la instalaci�n de la herramienta IBM Support Assistant Lite se trata simplemente de extraer los archivos del archivo .zip archivado
que ha generado y transferido desde el sistema de entorno de trabajo. Los archivos se pueden extraer en cualquier ubicaci�n del sistema que elija en el sistema donde ejecutar� la herramienta. Esto
crear� un subdirectorio ISALite debajo del directorio de destino. 


Utilizaci�n de la herramienta
-----------
Definici�n de la variable de entorno JAVA_HOME
Independientemente de si va a utilizar la herramienta IBM Support Assistant Lite en la modalidad de GUI o en la modalidad de consola de l�nea de mandatos, utilice
el mismo procedimiento para iniciarla: invoque el script de lanzamiento apropiado desde una l�nea de mandatos. En el caso de un sistema Windows, estos scripts de lanzamiento son archivos de proceso por lotes. Para los dem�s entornos, se trata de scripts de shell. 

Puesto que la herramienta no se implementa como una aplicaci�n Java, es necesario que se puede localizar el Java antes de que se pueda iniciar la herramienta. Si no est� disponible Java en la PATH, tendr� que definir la variable de entorno JAVA_HOME manualmente. La herramienta IBM Support Assistant Lite requiere un JRE en el nivel 1.4.2 o superior (1.5 o superior en Windows 7 de 64 bits), as� pues, en primer lugar, debe asegurarse de que est� instalado un JRE apropiado en el sistema donde se ejecutar� la herramienta. En caso afirmativo, deber� emitir un mandato espec�fico del sistema operativo para definir la variable JAVA_HOME para indicar este JRE.
El
    Microsoft JVM/JDK y gij (GNU libgcj) no est�n soportados. 

Por ejemplo, si en una plataforma Windows tiene instalado jre1.4.2 en
c:\jre1.4.2, establecer� JAVA_HOME mediante el mandato siguiente:

SET JAVA_HOME=c:\jre1.4.2
NOTA: no utilice comillas en el valor del mandato SET, aunque el	valor contenga espacios en blanco.

En una plataforma Linux, AIX, Solaris o iSeries, si tiene el JRE	instalado en
/opt/jre142, establecer� JAVA_HOME mediante el mandato	siguiente:

export JAVA_HOME=/opt/jre142


Inicio de la herramienta en la modalidad de GUI Swing
------------------------------------
Deber� emitir el siguiente script de lanzamiento: 

- Para el entorno Windows, ser� el script runISALite.bat del directorio \ISALite de la herramienta.
- Para los entornos Linux, AIX, HP-UX y Solaris, ser� el script runISALite.sh del directorio /ISALite de la herramienta. Aseg�rese de que el script runISALite.sh tenga permiso de ejecuci�n; puede utilizar el siguiente mandato para otorgar el permiso de ejecuci�n de archivo: chmod 755 runISALite.sh 

La modalidad de GUI no est� soportada en los entornos iSeries y zSeries: consulte la secci�n inmediatamente posterior a esta si desea informaci�n sobre c�mo iniciar la modalidad
de consola de l�nea de mandatos en iSeries y zSeries. 

Inicio de la herramienta en la modalidad de consola de l�nea de mandatos
-----------------------------------------------
Si no est� disponible una GUI, la herramienta debe iniciarse autom�ticamente en la modalidad de l�nea de mandatos. Si se desea la modalidad de consola incluso aunque no est� disponible una GUI, especifique "-console" en la l�nea de mandatos.
En algunas instancias, no ser� posible determinar que no est� disponible una GUI y la herramienta no se iniciar�. En estas instancias, la herramienta se deber� reiniciar mediante "-console".

Los archivos se escriben en el directorio de instalaci�n
-----------------------------------------------
De forma predeterminada, el directorio de instalaci�n de ISA Lite se utiliza para almacenar los archivos creados durante la ejecuci�n. En algunos sistemas, el directorio de instalaci�n de ISA Lite s�lo ser� de lectura. En este ejemplo, utilice el par�metro
-useHome. El par�metro provocar� que los archivos temporales se escriban en el directorio temporal de los sistemas y que los archivos
persistentes se escriban en el directorio de inicio del usuario. 
	
Interacci�n con la herramienta
---------------------------
Para ambas modalidades, la de GUI y la de consola de l�nea de mandatos, se le pedir� que configure varios campos como, por ejemplo, el nombre del archivo zip de recogida de datos
y cualquier otra informaci�n espec�fica del producto. 
				Despu�s de eso, seleccionar� la opci�n de problema y se realizar� la recogida de datos.


Cuando IBM Support Assistant Lite se ejecuta en la modalidad de texto, no hay listas de selecci�n ni campos de entrada para que especifique informaci�n el usuario.
En lugar de ello, se presentan opciones disponibles en forma
				de listas numeradas, y el usuario especifica el n�mero de la selecci�n seguido de la tecla Intro. Los campos de entrada
				se transforman en solicitudes, en las que se especifica la respuesta y se pulsa Intro. Cuando la recogida de datos ha
				finalizado, la salida es otro archivo ZIP que puede transferirse de nuevo manualmente a la m�quina en la que est�
				instalado IBM Support Assistant Workbench. Desde all�, el archivo ZIP de salida puede enviarse a IBM Support o
				examinarse localmente, igual que otras recogidas realizadas en IBM Support Assistant Workbench.


Para detener la herramienta de recopilador, escriba quit en la modalidad de texto o pulse el bot�n Salir en la modalidad de GUI. 

La herramienta le solicitar� los nombres de archivos. En las plataformas Unix, el uso de "~" como designaci�n del directorio HOME del usuario no est� soportado. Si se utiliza "~", se har� referencia a un subdirectorio debajo del directorio de trabajo actual por el nombre de "~".


*NOTA: lea la gu�a de usuario de IBM Support Assistant si desea m�s detalles. 

Determinaci�n de la informaci�n de versi�n
----------------------------------
De forma predeterminada, la versi�n de la herramienta (y sus distintos subcomponentes) se imprime en la consola desde laque se ha iniciado. Al realizar la ejecuci�n en la modalidad de GUI, la informaci�n de versi�n tambi�n se puede encontrar utilizando la opci�n del men� Ayuda->Acerca de.
Si Java no est� disponible, o la aplicaci�n Java no se puede iniciar, tambi�n puede obtener la versi�n de la herramienta ejecutando los scripts de lanzamiento con la opci�n "-version". 

*NOTA: Al utilizar la opci�n "-version", los scripts de lanzamiento imprimir�n la informaci�n de versi�n sin invocar realmente la herramienta. 

Visualizaci�n del archivo de inventario
----------------------
ISA Lite puede recopilar informaci�n de inventario del sistema actual. La salida es un archivo de inventario (inventory.xml), que se visualiza mejor con un navegador web.
Si el archivo de inventario est� presente, se puede visualizar desde la opci�n del men� Archivo-->Ver inventario en la GUI de ISA Lite. En windows, ISA Lite intentar� abrir el archivo de inventario utilizando el navegador predeterminado del sistema. En Linux, ISA Lite intenta abrir el archivo de inventario utilizando el navegador Firefox, por lo tanto, Firefox debe estar instalado y presente en la PATH. 

Problemas conocidos
----------------------------------
La instalaci�n de ISA Lite no se debe realizar en un directorio que incluya caracteres de espacio en blanco que incluyen espacios en plataformas Solaris. 

La instalaci�n de ISA Lite no se debe realizar en ning�n directorio que incluya caracteres de punto '.' en las plataformas Windows.
