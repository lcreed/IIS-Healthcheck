# (C) COPYRIGHT International Business Machines Corp., 2007
# All Rights Reserved * El�ments sous licence - Propri�t� d'IBM

-------------------------------------------------------------
Outil IBM Support Assistant Lite
-------------------------------------------------------------

Description
---------------

L'outil IBM Support Assistant Lite permet de collecter automatiquement les donn�es des produits IBM. L'outil est pr�configur� pour localiser les donn�es de diagnostic importantes sur votre syst�me informatique et les copier dans un fichier de collecteur. Le fichier journal g�n�r� par votre produit IBM et contenant l'historique d�taill� des �v�nements survenus durant le fonctionnement du produit est un exemple de donn�e de diagnostic. Un tel fichier peut �tre utilis� pour d�terminer la nature et la cause d'un incident logiciel.
Les fichiers d'initialisation, les fichiers de configuration, la version du syst�me d'exploitation, l'espace disque et les connexions r�seau sont �galement des donn�es de diagnostic.
Il est possible d'ex�cuter l'outil en mode interface graphique ou en mode console de ligne de commande. 
Le mode console vous offre un contr�le de ligne de commande des scripts de collecte IBM Support Assistant Lite.  L'outil inclut plusieurs fonctions qui vous assistent lorsque vous interagissez en mode console, notamment une fonction qui vous permet d'enregistrer vos r�ponses dans un fichier � partir d'une session en mode console, puis d'utiliser le fichier pour lancer des ex�cutions ult�rieures du m�me script de collecte.  

Installation et utilisation de l'outil
---------------------------
Dans la plupart des cas, la s�quence d'�tapes suivante permet une mise en route de l'outil.  Si vous rencontrez des probl�mes ou si vous avez besoin d'informations suppl�mentaires sur l'une des �tapes, vous pouvez consulter les sections qui suivent la pr�sente section.  

1.	Installez l'outil en proc�dant � l'extraction des fichiers du fichier archive que vous avez g�n�r� et transf�r� � partir du syst�me du plan de travail.
 - Extrayez l'outil dans le r�pertoire de votre choix.
 - Reportez-vous aux sections ci-dessous pour obtenir des d�tails sur les modalit�s d'ex�cution des extractions.  

2.	Ex�cutez l'outil en mode interface graphique ou en mode console de ligne de commande.  
 - Suivez la proc�dure d�crite ci-dessous pour d�finir la variable d'environnement JAVA_HOME. Apr�s quoi, vous pouvez ex�cuter le script de lancement.
 - Une fois que vous avez lanc� l'outil, suivez les instructions ci-dessous pour interagir avec ce dernier au moment d'une collecte.

Installation de l'outil
--------------------
Dans tous les cas, l'installation de l'outil IBM Support Assistant Lite consiste simplement � extraire les fichiers du fichier .zip archiv� que vous avez g�n�r� et transf�r� � partir du syst�me du plan de travail. Il est possible d'extraire les fichiers vers n'importe quel emplacement de syst�me de fichiers que vous choisissez, sur le syst�me o� vous ex�cuterez l'outil.    
Un sous-r�pertoire ISALite est ainsi cr�� sous votre r�pertoire cible.


Utilisation de l'outil
-----------
D�finition de la variable d'environnement JAVA_HOME
Quel que soit le mode d'utilisation de l'outil IBM Support Assistant Lite (interface graphique ou console de ligne de commande), vous utilisez la m�me proc�dure pour le d�marrer : vous appelez le script de lancement appropri� � partir d'une ligne de commande.  Dans le cas d'un syst�me Windows, ces scripts de lancement sont des fichiers de commandes.  Pour les autres environnements, il s'agit de scripts de shell.  

Etant donn� que l'outil est impl�ment� en tant qu'application Java, il est n�cessaire que Java puisse �tre localis� avant que l'outil puisse d�marrer. Si Java n'est pas disponible dans la variable PATH, vous devez d�finir la variable d'environnement JAVA_HOME manuellement. L'outil IBM Support Assistant Lite requiert un environnement JRE de niveau 1.4.2 ou sup�rieur (1.5 ou sup�rieur sous Windows 7 64 bits). Vous devez donc vous assurer, dans un premier temps, qu'un environnement JRE ad�quat est install� sur le syst�me o� l'outil sera ex�cut�. Si tel est le cas, vous devez �mettre une commande propre au syst�me d'exploitation pour d�finir la variable JAVA_HOME de fa�on � ce qu'elle pointe vers cet environnement JRE. Microsoft JVM/JDK et gij (GNU libgcj) ne sont pas pris en charge.
Par exemple, si sur une plateforme Windows, jre1.4.2 est install� � l'emplacement c:\jre1.4.2, vous devez configurer la variable JAVA_HOME avec la commande suivante :

SET JAVA_HOME=c:\jre1.4.2
REMARQUE : n'utilisez pas de guillemets dans la valeur de la commande SET, m�me si votre valeur contient des caract�res blancs.
Sur une plateforme Linux, AIX, Solaris ou iSeries, si JRE est install� � l'emplacement /opt/jre142, vous devez configurer la variable JAVA_HOME avec la commande suivante :

export JAVA_HOME=/opt/jre142


D�marrage de l'outil en mode interface graphique Swing
------------------------------------
Vous devez ex�cuter le script de lancement suivant :

- Environnement Windows : script runISALite.bat dans le r�pertoire \ISALite de l'outil.
- Environnements Linux, AIX, HP-UX et Solaris : script runISALite.sh dans le r�pertoire /ISALite de l'outil. Assurez-vous que le script
runISALite.sh script dispose d'un droit d'ex�cution. Vous pouvez utiliser la commande suivante pour attribuer au fichier un droit d'ex�cution : chmod 755 runISALite.sh

Le mode interface graphique n'est pas pris en charge dans les environnements iSeries et zSeries ; consultez la section qui suit imm�diatement la pr�sente section pour obtenir des informations sur les modalit�s de d�marrage de l'outil en mode console de ligne de commande sous iSeries et zSeries.

D�marrage de l'outil en mode console de ligne de commande
-----------------------------------------------
Si aucune interface graphique n'est disponible, l'outil doit d�marrer automatiquement en mode ligne de commande. Si le mode console est souhait� m�me si aucune interface graphique n'est disponible, sp�cifiez "-console" dans la ligne de commande. Dans certains cas, il est impossible de d�terminer qu'une interface graphique n'est pas disponible et l'outil ne d�marre donc pas. Dans ces cas, l'outil doit �tre red�marr� � l'aide de "-console". Les fichiers sont �crits dans le r�pertoire d'installation -----------------------------------------------
Par d�faut, le r�pertoire d'installation d'ISA Lite est utilis� pour enregistrer les fichiers cr��s lors de l'ex�cution. Sur certains syst�mes, le r�pertoire d'installation d'ISA Lite est en lecture seule. Dans ce cas, utilisez le param�tre -useHome. Ce param�tre permet d'�crire les fichiers temporaires dans le r�pertoire temporaire du syst�me et les fichiers permanents dans le r�pertoire de base de l'utilisateur. 
	
Interaction avec l'outil
---------------------------
Que ce soit pour le mode console de ligne de commande ou le mode interface graphique, vous devrez d�finir plusieurs zones, telles que le nom du fichier zip de la collecte de donn�es et toute autre information sp�cifique au produit. Ensuite, vous s�lectionnez l'option d'incident et la collecte de donn�es est effectu�e.

Lorsque l'outil IBM Support Assistant Lite s'ex�cute en mode texte, il ne comporte aucune liste de s�lection ou zone de saisie destin�e � l'utilisateur. 
Les choix disponibles sont pr�sent�s sous la forme de listes num�rot�es ; vous entrez le num�ro de votre s�lection et vous appuyez sur la touche Entr�e. Les zones de saisie sont transform�es en invites, dans lesquelles vous entrez votre r�ponse avant d'appuyer sur la touche Entr�e. Lorsque la collecte de donn�es est termin�e, il en r�sulte un autre fichier zip que vous pouvez manuellement transf�rer � nouveau vers la machine sur laquelle IBM Support Assistant Workbench est install�. A partir de l�, le fichier de sortie compress� peut �tre envoy� au support IBM ou examin� en local, comme dans le cas des collectes effectu�es dans IBM Support Assistant Workbench.

Pour arr�ter l'outil de collecte, entrez quit en mode texte ou cliquez sur le bouton Quitter en mode interface graphique.

L'outil invite � saisir les noms de fichier. Sur les plateformes Unix, l'utilisation de "~" pour d�signer le r�pertoire de base de l'utilisateur n'est pas prise en charge. Si "~" est utilis�, un sous-r�pertoire dans le r�pertoire de travail actuel avec le nom de "~" sera r�f�renc�.
*REMARQUE : veuillez lire le guide d'utilisation d'IBM Support Assistant pour plus de d�tails.

D�termination des informations de version
----------------------------------
Par d�faut, la version de l'outil (et ses diff�rents sous-composants) est affich�e sur la console � partir de laquelle l'outil a �t� lanc�. Lors d'une ex�cution en mode interface graphique, les informations de version sont �galement disponibles � partir de l'option de menu Aide->A propos de.
Si Java n'est pas disponible, ou si l'application Java ne peut pas d�marrer, vous pouvez �galement obtenir la version de l'outil en ex�cutant les scripts de lancement avec l'option "-version". *REMARQUE : lorsque vous utilisez l'option "-version", les scripts de lancement afficheront les informations de version sans r�ellement appeler l'outil.

Affichage du fichier d'inventaire
----------------------
ISA Lite peut collecter les informations d'inventaire du syst�me actuel. La sortie d'un fichier d'inventaire (inventory.xml), dont la visualisation est optimis�e avec un navigateur Web.
Si le fichier d'inventaire est pr�sent, il peut �tre affich� � partir de l'option de menu Fichier->Afficher l'inventaire dans l'interface graphique d'ISA Lite. Sous Windows, ISA Lite tente d'ouvrir le fichier d'inventaire � l'aide du navigateur par d�faut du syst�me. Sous Linux, ISA Lite tente d'ouvrir le fichier d'inventaire � l'aide du navigateur Firefox. C'est pour cette raison que Firefox doit �tre install� et pr�sent dans PATH.
Incidents connus
----------------------------------
L'installation d'ISA Lite ne doit pas �tre effectu�e dans un r�pertoire qui contient des caract�res blancs, notamment les espaces sur les plateformes Solaris.

L'installation d'ISA Lite ne doit pas �tre effectu�e dans un r�pertoire qui contient des caract�res de point '.' sur les plateformes Windows.
