# (C) COPYRIGHT International Business Machines Corp., 2007
# Tutti i diritti riservati * Materiali su licenza - Propriet� di IBM

-------------------------------------------------------------
Strumento IBM Support Assistant Lite
-------------------------------------------------------------

Descrizione
---------------

Lo strumento IBM Support Assistant Lite mette a disposizione la raccolta dati automatica per prodotti IBM. Lo strumento � preconfigurato per individuare importanti dati diagnostici sul
computer e per copiarli in un file del programma di raccolta. Un esempio di dati diagnostici � un file di log
generato dal prodotto IBM, che contiene una cronologia dettagliata di eventi verificatisi
durante l'attivit� del prodotto. Tale file pu� essere utile per determinare la natura e la causa
di un problema software.
Altri esempi di dati diagnostici includono file di inizializzazione, file di configurazione, versione di
sistema operativo, spazio disco e connessioni di rete.
Lo strumento pu� essere eseguito in modalit� GUI o in modalit� console di riga comandi. 
La modalit� console fornisce all'utente il controllo da riga comandi degli script di raccolta di
IBM Support Assistant Lite.  Lo strumento contiene alcune funzioni utili per l'interazione in
modalit� console, incluso una funzione che consente di registrare le risposte di una
sessione di modalit� console in un file ed utilizzare in seguito il file per condurre le successive esecuzioni
dello stesso script di raccolta.  

Installazione d utilizzo dello strumento
-----------------------------------------
Nella maggior parte dei casi, la seguente sequenza di passi � in grado di installare ed eseguire lo strumento.  Se si verificano problemi o se
si desiderano ulteriori informazioni su uno qualsiasi dei passi, � possibile fare riferimento alle sezioni riportate di seguito a questa.  

1.	Installare lo strumento estraendo i file dal file di archivio generato e trasferito dal sistema Workbench.
 - Estrarre lo strumento in una directory a scelta.
 - Leggere le sezioni riportate di seguito per ulteriori dettagli sull'esecuzione delle estrazioni.  

2.	Eseguire lo strumento in modalit� GUI o in modalit� console di riga comandi.  
 - Seguire la procedura descritta in seguito per l'impostazione della variabile di ambiente JAVA_HOME. Una volta effettuata questa operazione, � possibile eseguire lo script di avvio.
 - Dopo aver avviato lo strumento, seguire le istruzioni riportate di seguito per interagire con esso quando esegue una raccolta.

Installazione dello strumento
-----------------------------
In tutti i casi, l'installazione dello strumento IBM Support Assistant Lite � semplicemente una questione di estrazione dei file dal file .zip archiviato
generato dall'utente e trasferito dal sistema Workbench. I file possono essere estratti in qualunque ubicazione del file system scelta sul sistema in cui verr� eseguito lo strumento.    
In questo modo verr� creata una sottodirectory ISALite nella directory di destinazione.


Utilizzo dello strumento
------------------------
Impostazione della variabile di ambiente JAVA_HOME
A prescindere dal tipo di modalit� di utilizzo dello strumento IBM Support Assistant Lite, ovvero in modalit� GUI o in modalit� console di riga comandi, viene utilizzata
la stessa procedura per avviarlo: viene richiamato lo script di avvio appropriato da una riga comandi.  Nel caso di un sistema Windows, gli script di avvio
sono file batch.  Per altri ambienti, sono script di shell.  

Poich� lo strumento viene implementato come applicazione Java, � necessario poter individuare Java prima di poter avviare lo strumento. Se Java
non � disponibile nel PATH, � necessario impostare la variabile di ambiente JAVA_HOME manualmente.  
Lo strumento IBM Support Assistant Lite richiede un JRE al livello della versione 1.4.2 o successive
(1.5 o successive su Windows 7 a 64 bit), quindi � necessario, in primo luogo, accertarsi che, sul sistema su cui sar� in esecuzione lo strumento,
sia installato un JRE idoneo. Se � installato, � necessario inviare un comando specifico per il sistema operativo per impostare la variabile JAVA_HOME in modo che punti al JRE. Microsoft JVM/JDK e gij (GNU libgcj) non sono supportati. 

Ad esempio, se su una piattaforma Windows jre1.4.2 fosse installato in
c:\jre1.4.2, si dovrebbe impostare JAVA_HOME utilizzando il seguente comando:

SET JAVA_HOME=c:\jre1.4.2
NOTA: non utilizzare le virgolette nel valore del comando SET, anche nel caso in cui il valore contenga spazi.

Su una piattaforma Linux, AIX, Solaris o iSeries, se JRE fosse installato in
/opt/jre142, si dovrebbe impostare JAVA_HOME utilizzando il seguente comando:

export JAVA_HOME=/opt/jre142


Avvio dello strumento in modalit� GUI Swing
------------------------------------
Sar� necessario eseguire questo script di avvio:

- Per l'ambiente Windows, si tratter� dello script runISALite.bat nella directory \ISALite dello strumento.
- Per gli ambienti Linux, AIX, HP-UX e Solaris, si tratter� dello script runISALite.sh nella directory /ISALite dello strumento. Accertarsi che lo
script runISALite.sh disponga del permesso di esecuzione; � possibile utilizzare il
seguente comando per concedere il permesso per l'esecuzione di un file: chmod 755 runISALite.sh

La modalit� GUI non � supportata negli ambienti iSeries e zSeries: consultare la sezione immediatamente
successiva alla presente per informazioni su come avviare lo strumento in modalit� Console di riga comandi
su iSeries e zSeries.

Avvio dello strumento in modalit� Console di riga comandi
-----------------------------------------------
Se non � disponibile una GUI, lo strumento dovrebbe avviarsi automaticamente in modalit� riga comandi.  Se si preferisce utilizzare
la modalit� console nonostante la disponibilit� di una GUI, specificare l'opzione "-console" sulla riga comandi.
In alcuni casi, non sar� possibile stabilire l'eventuale indisponibilit� di una GUI
e lo strumento non si avvier�.  In tali casi, sar� necessario riavviare lo strumento
utilizzando l'opzione "-console".

I file vengono scritti nella directory di installazione
-----------------------------------------------
Per impostazione predefinita, viene utilizzata la directory di installazione di ISA Lite per memorizzare i file creati nel corso dell'esecuzione.  Su alcuni sistemi, la directory di installazione ISA Lite sar� di sola lettura.  In questo caso, utilizzare
il parametro -useHome.  Tale parametro far� s� che i file temporanei vengano
scritti nella directory temporanea dei sistemi e quelli permanenti nella directory principale dell'utente. 
	
Interazione con lo strumento
---------------------------
Sia in modalit� GUI che Console di riga comandi all'utente verr� richiesta la compilazione di vari campi, ad esempio il nome del file zip di raccolta dati e qualsiasi
altra informazione specifica per il prodotto. Dopo avere eseguito questa operazione, selezionare l'opzione relativa al problema per eseguire la
raccolta dati.

Quando IBM Support Assistant Lite viene eseguito in modalit� testo, non vi sono elenchi di selezione o campi di immissione per l'input utente. 
Le opzioni disponibili sono presentate come elenchi
numerati ed � possibile immettere il numero dell'opzione seguito dal tasto Invio. I campi di
input sono convertiti in richieste in cui si immette la risposta e si preme Invio. Al termine della
raccolta dati, l'output � un altro file ZIP che � possibile trasferire manualmente sulla macchina
in cui � installato IBM Support Assistant Workbench. Da tale macchina, il file ZIP di output
pu� essere inviato al supporto IBM o esaminato localmente, come avviene con altre raccolte eseguite
in IBM Support Assistant Workbench.

Per arrestare lo strumento di raccolta, immettere quit nella modalit� di testo, o fare clic sul pulsante Esci nella modalit� GUI.

Lo strumento richieder� i nomi file.  Sulle piattaforme Unix, l'utilizzo di "~" come designazione della directory HOME dell'utente non
� supportato.  Se si utilizza "~", si far� riferimento ad una sottodirectory nella directory di lavoro presente, dal nome "~".

*NOTA: per ulteriori dettagli leggere la guida per l'utente di IBM Support Assistant.

Individuazione delle informazioni sulla versione
----------------------------------
Per impostazione predefinita, la versione dello strumento (e dei vari sottocomponenti) viene stampata nella console da cui � stato
avviato.  Quando l'esecuzione avviene in modalit� GUI, le informazioni sulla versione possono anche venire reperite utilizzando l'opzione di menu Guida->Informazioni su.
Se Java non � disponibile o l'applicazione Java non � in grado di avviarsi, si pu� ottenere la versione dello strumento
anche eseguendo gli script di avvio con l'opzione "-version".

*NOTA: Quando si utilizza l'opzione "-version", gli script di avvio stamperanno le informazioni sulla versione senza richiamare
effettivamente lo strumento.

Visualizzazione del file di inventario
----------------------
ISA Lite � in grado di raccogliere le informazioni di inventario relative al sistema corrente. L'output � un file di inventario (inventory.xml), che viene visualizzato nel modo migliore mediante un browser Web.
Se il file di inventario � presente, lo si pu� visualizzare tramite l'opzione di menu File-->Visualizza inventario nella GUI di ISA Lite. Su Windows, ISA Lite tenter� di aprire il file di inventario
utilizzando il browser predefinito del sistema. Su Linux, ISA Lite tenta invece di aprire il file di inventario utilizzando il browser firefox, quindi, firefox deve essere installato e si deve trovare in PATH.

Problemi noti
----------------------------------
L'installazione di ISA Lite non dovrebbe essere effettuata in una directory che includa spazi
nelle piattaforme Solaris.

L'installazione di ISA Lite non dovrebbe essere effettuata in una directory che includa caratteri punto '.' nelle piattaforme Windows.
