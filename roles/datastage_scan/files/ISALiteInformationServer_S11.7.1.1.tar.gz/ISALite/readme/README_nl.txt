# (C) COPYRIGHT International Business Machines Corp., 2007
# Alle rechten voorbehouden * Gelicentieerd materiaal - Eigendom van IBM 

-------------------------------------------------------------
IBM Support Assistant Lite
-------------------------------------------------------------

Beschrijving
---------------

Met IBM Support Assistant Lite kunt u automatisch gegevens verzamelen over IBM-producten. Dit hulpprogramma is standaard zo geconfigureerd dat
belangrijke diagnosegegevens over uw computersysteem worden verzameld en naar een Collector-bestand worden gekopieerd. De diagnosegegevens kunnen bijvoorbeeld bestaan uit een logboekbestand dat door uw IBM-product is gegenereerd en dat een gedetailleerd historisch overzicht bevat van de events
die bij het werken met dat product hebben plaatsgevonden. Zo'n bestand kan waardevol zijn bij het bepalen van de aard en de oorzaak van een softwareprobleem.
Andere voorbeelden van diagnosegegevens zijn initialisatiebestanden, configuratiebestanden, besturingssysteemversie, schijfruimte en netwerkverbindingen. Deze tool kan worden uitgevoerd in de GUI-modus of in een opdrachtregelconsolemodus.
De consolemodus biedt de mogelijkheid om de IBM Support Assistant Lite-verzamelscripts vanaf de opdrachtregel te besturen.  De tool bevat verschillende functies die u helpen wanneer u er in de consolemodus mee wilt werken, zoals het vastleggen van uw reacties tijdens een consolemodussessie in een bestand zodat dit bestand kan worden gebruikt voor het aansturen van toekomstige uitvoeringen van hetzelfde verzamelscript. 

Installatie en gebruik van de tool
---------------------------
In de meeste gevallen kunt u door het uitvoeren van de onderstaande stappen de tool installeren en in gebruik nemen. Wanneer u op problemen stuit, of als u meer informatie wilt hebben over een van deze stappen, raadpleegt u de gedeelten die na dit gedeelte volgen.

1.	Installeer de tool door het uitpakken van het archiefbestand dat u hebt gegenereerd en overgebracht vanaf het Workbench-systeem.
 - Pak de tool uit in elke gewenste directory.
 - Zie de ondertaande gedeelten voor meer informatie over het uitpakken van het bestand.

2.	Voer de tool uit in de GUI-modus of de opdrachtregelconsolemodus. 
 - Voer de hieronder beschreven procedure uit voor het instellen van de omgevingsvariabele JAVA_HOME. Wanneer u dit  eenmaal hebt gedaan, kunt u het startscript uitvoeren.
 - Als de tool is gestart, volgt u de onderstaande instructies voor interactie met de tool tijdens het verzamelen van gegevens. 

De tool installeren
--------------------
In alle gevallen is de installatie van de IBM Support Assistant Lite-tool een kwestie van het uitpakken van het gearchiveerde ZIP-bestand dat u hebt gegenereerd en overgebracht vanaf het Workbench-systeem. De bestanden kunnen worden uitgepakt op elke gewenste locatie op het systeem waarop u de tool wilt uitvoeren. Als u de bestanden uitpakt, wordt er een ISALite-subdirectory onder uw doeldirectory gemaakt.


Gebruik van de tool
-----------
De omgevingsvariabele JAVA_HOME instellen
Ongeacht of u IBM Support Assistant Lite in de GUI-modus of in de opdrachtregelconsolemodus wilt gebruiken, is de procedure om de tool te starten hetzelfde: u roept het betreffende startscript op vanaf een opdrachtregel. In het geval u op een Windows-systeem werkt, zijn deze startscripts batchbestanden. Voor de overige omgevingen zijn het shellscripts. 

Aangezien de tool is ge�mplementeerd als een Java-toepassing, is het een vereiste dat Java kan worden gevonden voordat de tool kan starten. Als Java niet in het PATH voorkomt, moet u de omgevingsvariabele JAVA_HOME handmatig instellen.
Voor de IBM Support Assistant Lite-tool is JRE met versienummer 1.4.2 of hoger (1.5 of hoger op Windows 7 64 bits) vereist, dus u moet eerst controleren of er een geschikte JRE is ge�nstalleerd op het systeem waarop de tool zal worden gebruikt. Als dat het geval is, moet u een bij het besturingssysteem passende opdracht opgeven om de variabele JAVA_HOME naar deze JRE te laten verwijzen. De Microsoft JVM/JDK en gij (GNU libgcj) worden niet ondersteund. 

Voorbeeld: Als in een Windows-platform jre1.4.2 in c:\jre1.4.2 is ge�nstalleerd, stelt u JAVA_HOME in met de volgende opdracht: 

SET JAVA_HOME=c:\jre1.4.2
OPMERKING: Plaats de waarde van de opdracht SET niet tussen aanhalingstekens, ook niet als de waarde een of meer spaties bevat. 

Als in een Linux-, AIX-, Solaris- of iSeries-platform de JRE in /opt/jre142 is ge�nstalleerd, stelt u JAVA_HOME in met de volgende opdracht: 

export JAVA_HOME=/opt/jre142


De tool in de Swing GUI-modus starten
------------------------------------
U moet het volgende startscript uitvoeren:

- Voor de Windows-omgeving is dit het script runISALite.bat in de directory \ISALite van de tool.
- Voor de Linux, AIX, HP-UX en Solaris-omgeving is dit het script runISALite.sh in de directory /ISALite van de tool. Controleer of aan het script runISALite.sh uitvoermachtiging is toegekend; u kunt deze machtiging met de volgende opdracht verlenen: chmod 755 runISALite.sh

De GUI-modus wordt niet ondersteund in een iSeries- en zSeries-omgeving: raadpleeg het gedeelte hierna voor informatie over het starten van de tool in de opdrachtregelconsolemodus in iSeries en zSeries. 

De tool starten in opdrachtregelconsolemodus
------------------------------------------------------
Als er geen GUI beschikbaar is, moet de tool automatisch worden gestart in opdrachtregelmodus. Als de consolemodus de voorkeur heeft, zelfs indien er een GUI beschikbaar is, geef dan op de opdrachtregel "-console" op. In sommige gevallen is het niet mogelijk om te bepalen of er een GUI beschikbaar is, en wordt de tool niet gestart. In deze gevallen moet de tool opnieuw worden gestart door het opgeven van "-console".

Bestanden worden weggeschreven naar de installatiedirectory
-----------------------------------------------------------
Standaard wordt de installatiedirectory van ISA Lite gebruikt voor het opslaan van bestanden die zijn gemaakt tijdens de uitvoering. Op sommige systemen kan de installatiedirectory van ISA Lite alleen worden gelezen. In dit geval gebruikt u de parameter -useHome. Door deze parameter worden tijdelijke bestanden weggeschreven naar de tijdelijke directory van deze systemen, en worden persistente bestanden weggeschreven naar de hoofddirectory van de gebruiker. 
	
Interactie met de tool
----------------------
Voor zowel de GUI- als de opdrachtregelconsolemodus moet u een aantal gegevens invullen, zoals de naam van het ZIP-bestand met de verzamelde gegevens en andere productspecifieke gegevens. Daarna selecteert u de probleemoptie en kunnen de gegevens worden verzameld. 

Wanneer IBM Support Assistant Lite in de tekstmodus wordt uitgevoerd, kunt u geen waarden uit selectielijsten kiezen of in invoervelden opgeven.
De opties worden in plaats daarvan als genummerde lijsten afgebeeld, waarbij u het nummer van uw keuze typt en vervolgens op Enter drukt. De invoervelden worden afgebeeld als aanwijzingen, waarbij u uw antwoord opgeeft en op Enter drukt. Nadat
de gegevensverzameling is voltooid, kunt u het afzonderlijke ZIP-bestand met de
uitvoer handmatig weer overbrengen naar de computer waarop IBM Support Assistant Workbench is ge�nstalleerd. Via die computer kunt u het ZIP-uitvoerbestand naar de ondersteuningsafdeling van IBM verzenden of ter plekke controleren, net als bij andere gegevensverzamelingen in IBM Support Assistant Workbench.


U kunt de tool stoppen door de opdracht "quit" te typen in de tekstmodus of op de knop Be�indigen te klikken in de GUI-modus.

Er kan gevraagd worden om bestandsnamen. Op Unix-platforms wordt het gebruik van "~" als aanduiding van de HOME-directory van de gebruiker niet ondersteund. Als het teken "~" wordt gebruikt, wordt er verwezen naar een subdirectory onder de huidige werkdirectory met de naam "~".


*OPMERKING: Lees de gebruikershandleiding bij IBM Support Assistant voor meer details.

Versiegegevens vaststellen
--------------------------
Standaard wordt de versie van de tool (en de verschillende subcomponenten daarvan) weergegeven op de console vanaf welke deze is gestart. Als het programma wordt uitgevoerd in GUI-modus, zijn versiegegevens ook beschikbaar via de menuoptie Help->Info.
Als Java niet beschikbaar is, of de Java-toepassing niet kan worden gestart, kunt u de versie van de tool ook ophalen door de startscripts uit te voeren met de optie "-version".

*Opmerking: Wanneer u de optie "-version" gebruikt, geven de startscripts de versiegegevens weer zonder dat de tool daadwerkelijk wordt opgeroepen.

Inventarisbestand weergeven
---------------------------
ISA Lite kan de inventarisgegevens van het huidige systeem verzamelen. De uitvoer is een inventarisatiebestand (inventory.xml), dat het beste kan worden bekeken in een webbrowser.
Als het inventarisatiebestand aanwezig is, kan het worden weergegeven via de menuoptie Bestand-->Inventaris weergeven in de GUI van ISA Lite. In Windows probeert ISA Lite het inventarisatiebestand te openen met de standaardbrowser van het systeem. Op Linux probeert ISA Lite het inventarisatiebestand te openen met de browser Firefox. Daarom moet Firefox ge�nstalleerd zijn en toegevoegd worden aan de omgevingsvariabele PATH.

Bekende problemen
----------------------------------
De installatie van ISA Lite moet op Solaris-platforms niet worden uitgevoerd in een directory die witruimtetekens bevat, zoals spaties. 

De installatie van ISA Lite moet op Windows-platforms niet worden uitgevoerd in een directory die punten '.' bevat.
