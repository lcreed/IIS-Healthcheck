# (C) COPYRIGHT International Business Machines Corp., 2007
# All Rights Reserved * Licensed Materials - Property of IBM

-------------------------------------------------------------
IBM Support Assistant Data Collector Tool
-------------------------------------------------------------

Beskrivelse
---------------

IBM Support Assistant (ISA) Data Collector Tool gir automatisk datainnsamling for IBM-produkter. Verkt�yet er forh�ndskonfigurert for � finne
viktige diagnosedata p� datasystemet ditt og kopiere dem til en innsamlingsfil. Et eksempel p� diagnosedata er en loggfil som genereres av
IBM-produktet og som inneholder en detaljert historikk over det som har skjedd mens produktet ble brukt. En slik fil kan v�re nyttig for �
finne informasjon om og �rsaken til et programvareproblem. Andre eksempler p� diagnosedata er initialiseringsfiler, konfigurasjonsfiler,
operativsystemversjon, lagerplass og nettverkstilkoblinger. 

Installering/bruk
----------------------
DEFINERE JAVA_HOME-variabelen:
For at verkt�yet skal virke p� riktig m�te, m� du s�rge for at milj�variabelen JAVA_HOME
er satt til JRE-versjon 1.4.2 eller h�yere.
Hvis du for eksempel p� en Windows-plattform har jre1.4.2 installert p�
c:\jre1.4.2, definerer du JAVA_HOME med f�lgende kommando:

SET JAVA_HOME=c:\jre1.4.2
MERK: Ikke bruk anf�rselstegn i SET-kommandoen, selv om verdien har blanktegn.

Hvis du p� Linux-, AIX-, Solaris- eller iSeries-plattformen har JRE
installert i /opt/jre142, definerer du JAVA_HOME med f�lgende kommando:

export JAVA_HOME=/opt/jre142

Windows:

	1) Pakk ut den arkiverte zip-filen
	2) G� til katalogen der du pakket ut zip-filen
	3) Kj�r startcollector.bat

Unix:

	1) Pakk ut den arkiverte zip-filen
	2) G� til katalogen der du pakket ut zip-filen
	3) S�rg for at alle skallskriptene har utf�ringstillatelse. Du kan bruke f�lgende kommando til � gi filen utf�ringstillatelse: chmod -R 755 `find . -name '*.sh'`
	4) Run ./startcollector.sh
	
iSeries:
 1) Pakk ut den arkiverte zip-filen
	2) G� til katalogen der du pakket ut zip-filen
	3) S�rg for at alle skallskriptene har utf�ringstillatelse. Du kan bruke f�lgende kommando til � gi filen utf�ringstillatelse: chmod -R 755 `find . -name '*.sh'`
	4) Run ./startcollector_iseries.sh
	
zSeries:
 1) Pakk ut den arkiverte zip-filen
	2) G� til katalogen der du pakket ut zip-filen
	3) S�rg for at alle skallskriptene har utf�ringstillatelse. Du kan bruke f�lgende kommando til � gi filen utf�ringstillatelse: chmod -R 755 `find . -name '*.sh'`
	4) Kj�r ./startcollector_zseries.sh 

------------------------------------------------------------------------------------------------------------------------------------------------------------------------
**MERK: Verkt�yet krever at det er installert en JRE p� systemet, versjon 1.4.2 eller senere.
Microsoft JVM/JDK st�ttes ikke. ------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Du m� konfigurere flere felt f�r du utf�rer datainnsamlingen, for eksempel navnet p�
zip-filen for datainnsamlingen og eventuelle andre produktspesifikke opplysninger. 
Etter dette velger du problemalternativet, s� blir datainnsamlingen utf�rt.


Du stopper innsamlerverkt�yet ved � skrive quit.

*MERK: Du finner mer informasjon i brukerh�ndboken for IBM Support Assistant v4.

