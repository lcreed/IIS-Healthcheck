# (C) COPYRIGHT International Business Machines Corp. 2007
# Wszelkie prawa zastrze�one * Materia�y licencjonowane - w�asno�� IBM

-------------------------------------------------------------
Narz�dzie IBM Support Assistant Lite
-------------------------------------------------------------

Opis
---------------

Narz�dzie IBM Support Assistant Lite udost�pnia automatyczne gromadzenie danych dla produkt�w IBM. Konfiguracja fabryczna tego narz�dzia umo�liwia odnajdywanie istotnych danych
diagnostycznych na u�ywanym systemie komputerowym i kopiowanie ich do pliku modu�u gromadz�cego dane. Przyk�adem
danych diagnostycznych jest plik dziennika wygenerowany przez produkt IBM, zawieraj�cy szczeg�ow�
histori� zdarze�, kt�re mia�y miejsce w trakcie jego dzia�ania. Plik taki mo�e by� bardzo pomocny przy
okre�laniu rodzaju i przyczyny b��du oprogramowania.
Inne przyk�ady danych diagnostycznych to: pliki inicjuj�ce, pliki konfiguracyjne, wersja systemu operacyjnego,
miejsce na dysku i po��czenia sieciowe.
Narz�dzie mo�na uruchamia� w trybie GUI lub w trybie konsoli wiersza komend. 
Tryb konsoli umo�liwia sterowanie skryptami gromadzenia danych programu IBM Support Assistant Lite z wiersza komend.  Narz�dzie obejmuje wiele opcji pomagaj�cych w interakcji z nim w trybie konsoli, mi�dzy innymi opcj� umo�liwiaj�c� rejestrowanie odpowiedzi z sesji trybu konsoli w pliku, a nast�pnie dalsze uruchomienia tego samego skryptu gromadzenia danych za pomoc� tego pliku.  

Instalacja i u�ywanie narz�dzia
---------------------------
W wi�kszo�ci przypadk�w uruchomienie narz�dzia wymaga wykonania nast�puj�cych czynno�ci.  W przypadku problem�w lub aby uzyska� wi�cej informacji na temat kt�rego� z tych krok�w, mo�na odwo�a� si� do poni�szych sekcji.  

1.	Zainstaluj narz�dzie, wyodr�bniaj�c pliki z wygenerowanego i przes�anego z systemu Workbench archiwum.
 - Wyodr�bnij narz�dzie w dowolnie wybranych katalogu.
 - W poni�szych sekcjach opisano szczeg�y wyodr�bniania.  

2.	Uruchom narz�dzie w trybie GUI lub w trybie konsoli wiersza komend.  
 - Wykonaj opisan� poni�ej procedur� ustawiania zmiennej �rodowiskowej JAVA_HOME. Nast�pnie mo�na wykona� skrypt uruchamiania.
 - Po uruchomieniu narz�dzia wykonaj poni�sze instrukcje interakcji z nim w trakcie gromadzenia danych.

Instalowanie narz�dzia
--------------------
We wszystkich przypadkach instalacja narz�dzia IBM Support Assistant Lite sprowadza si� do wyodr�bnienia plik�w z archiwum .zip wygenerowanego w systemie Workbench i przes�anego z niego. Pliki mo�na wyodr�bni� w dowolnym miejscu systemu plik�w, w kt�rym narz�dzie b�dzie uruchamiane.    
Spowoduje to utworzenie podkatalogu ISALite w katalogu docelowym.


Korzystanie z narz�dzia
-----------
Ustawienie zmiennej �rodowiskowej JAVA_HOME
Niezale�nie od tego, czy narz�dzie IBM Support Assistant Lite b�dzie u�ywane w trybie GUI, czy w trybie konsoli wiersza komend, uruchamia si� je tak samo: nale�y wywo�a� odpowiedni skrypt uruchomieniowy z wiersza komend.  W systemie Windows skrypty uruchomieniowe s� plikami wsadowymi.  W innych �rodowiskach s� one skryptami pow�oki.  

Poniewa� narz�dzie jest zaimplementowane jako aplikacja j�zyka Java, przed jego uruchomieniem nale�y znale�� interpreter tego j�zyka. Je�li interpreter j�zyka Java jest niedost�pny w �cie�ce okre�lonej przez zmienn� �rodowiskow� PATH, trzeba ustawi� zmienn� �rodowiskow� JAVA_HOME r�cznie.  
Narz�dzie IBM Support Assistant Lite wymaga �rodowiska JRE w wersji 1.4.2 lub
nowszej (wersja 1.5 lub nowsza w 64-bitowym systemie Windows 7), dlatego nale�y
najpierw upewni� si�, �e w systemie jest zainstalowane odpowiednie �rodowisko
JRE. Je�li tak, to trzeba uruchomi� komend� systemu operacyjnego tak, aby zmienna JAVA_HOME wskazywa�a na to �rodowisko JRE. 
�rodowiska Microsoft JVM/JDK i gij (biblioteka libgcj GNU) nie s� obs�ugiwane. 

Na przyk�ad, je�li na platformie Windows �rodowisko jre 1.4.2 jest zainstalowane
w katalogu c:\jre1.4.2, nale�y ustawi� zmienn� JAVA_HOME przy u�yciu nast�puj�cej komendy:

SET JAVA_HOME=c:\jre1.4.2
UWAGA: w argumencie komendy SET nie nale�y stosowa� znak�w cudzys�owu, nawet je�li argument ten zawiera bia�e znaki.

Na platformach Linux, AIX, Solaris lub iSeries, je�li �rodowisko JRE jest zainstalowane
w katalogu /opt/jre142, nale�y ustawi� zmienn� JAVA_HOME przy u�yciu nast�puj�cej komendy:

export JAVA_HOME=/opt/jre142


Uruchamianie narz�dzia w trybie Swing GUI
------------------------------------
Nale�y uruchomi� nast�puj�cy skrypt uruchomieniowy:

- W �rodowisku Windows b�dzie to skrypt runISALite.bat w katalogu \ISALite narz�dzia.
- W �rodowiskach Linux, AIX, HP-UX i Solaris b�dzie to skrypt runISALite.sh w katalogu /ISALite narz�dzia. Sprawd�, czy skrypt runISALite.sh ma uprawnienie do wykonania; mo�na u�y� nast�puj�cej komendy, aby nada� plikowi to uprawnienie: chmod 755 runISALite.sh

Tryb GUI nie jest obs�ugiwany w �rodowiskach iSeries i zSeries: w dalszej sekcji opisano, jak uruchamia� narz�dzie w trybie konsoli wiersza komend w systemach iSeries i zSeries. 

Uruchamianie narz�dzia w trybie konsoli wiersza komend
-----------------------------------------------
Je�li interfejs GUI nie jest dost�pny, narz�dzie powinno uruchomi� si� automatycznie w trybie wiersza
komend. Je�li pomimo dost�pno�ci interfejsu GUI jest wymagany tryb konsoli,
nale�y w wierszu komend poda� parametr -console.
W niekt�rych przypadkach nie b�dzie mo�liwe okre�lenie niedost�pno�ci
interfejsu GUI i narz�dzie nie zostanie uruchomione. W takich sytuacjach nale�y
zrestartowa� narz�dzie, korzystaj�c z parametru -console. 

Pliki s� zapisywane w katalogu instalacyjnym
-----------------------------------------------
Domy�lnie do przechowywania plik�w utworzonych podczas wykonywania jest u�ywany
katalog instalacyjny produktu ISA Lite.
W niekt�rych systemach katalog instalacyjny produktu ISA Lite b�dzie dost�pny
tylko do odczytu.
W takiej sytuacji nale�y u�y� parametru -useHome. Ten parametr spowoduje
zapisywanie plik�w tymczasowych w katalogu tymczasowym system�w i plik�w
trwa�ych w katalogu domowym u�ytkownika. 
Interakcja z narz�dziem
---------------------------
Zar�wno w przypadku interfejsu GUI, jak i trybu konsoli wiersza komend u�ytkownik zostanie poproszony o skonfigurowanie kilku p�l, na przyk�ad
nazwy pliku ZIP zebranych danych czy innych informacji charakterystycznych dla
produktu. Nast�pnie nale�y wybra� opcj� problemu, co powoduje rozpocz�cie operacji gromadzenia danych.

Kiedy program IBM Support Assistant Lite dzia�a w trybie tekstowym, u�ytkownik nie ma do dyspozycji list wyboru ani p�l wprowadzania. 
Zamiast nich dost�pne opcj� s� reprezentowane przez numerowane listy. U�ytkownik musi wprowadzi� numer wybranej opcji, a nast�pnie nacisn�� klawisz Enter. Zamiast p�l wej�ciowych
				stosowane s� podpowiedzi. U�ytkownik musi wpisa� odpowied� i nacisn�� klawisz Enter. Po zako�czeniu gromadzenia danych
				dane wyj�ciowe zapisywane s� w postaci pliku ZIP, kt�ry mo�na r�cznie przes�a� z powrotem na komputer, na kt�rym
				zainstalowane jest �rodowisko robocze programu IBM Support Assistant. Stamt�d plik wyj�ciowy ZIP mo�na wys�a� do dzia�u wsparcia IBM lub sprawdzi� lokalnie,
				tak samo, jak w przypadku innych danych zgromadzonych w �rodowisku roboczym programu IBM Support Assistant.

Aby zatrzyma� narz�dzie gromadzenia, w trybie tekstowym wpisz quit lub naci�nij przycisk Wyj�cie w trybie GUI.

Narz�dzie wy�wietli pytanie o nazwy plik�w. Na platformach Unix u�ycie znaku
�~� jako oznaczenia katalogu osobistego (HOME) u�ytkownika nie jest
obs�ugiwane. Je�li zostanie u�yty znak �~�, przywo�any zostanie podkatalog w
obecnym katalogu roboczym o nazwie �~�.


*UWAGA: Dalsze szczeg�y zawiera podr�cznik u�ytkownika programu IBM Support Assistant.

Okre�lanie informacji o wersji
----------------------------------
Domy�lnie wersja narz�dzia (i jego r�nych komponent�w podrz�dnych) jest
wy�wietlana w konsoli, z poziomu kt�rej zosta�o ono uruchomione. Je�li narz�dzie dzia�a w trybie interfejsu GUI, informacje o wersji
mo�na znale�� r�wnie� przy u�yciu opcji Pomoc->Informacje.
Je�li nie jest dost�pny j�zyk Java lub nie mo�na uruchomi� aplikacji Java,
mo�na r�wnie� uzyska� informacje o wersji narz�dzia, wywo�uj�c skrypty
uruchamiania z opcj� -version. 

*UWAGA: skrypty uruchamiania wywo�ane z u�yciem opcji -version wy�wietl�
informacje o wersji bez wywo�ania narz�dzia. 

Wy�wietlanie pliku zasob�w
----------------------
Produkt ISA Lite mo�e zgromadzi� informacje o zasobach bie��cego systemu. Dane
wyj�ciowe stanowi plik zasob�w (inventory.xml), kt�ry najlepiej przegl�da� z
u�yciem przegl�darki WWW.
Je�li istnieje plik zasob�w, mo�na go przegl�da� za pomoc� opcji menu
Plik-->Wy�wietl spis zasob�w interfejsu GUI produktu ISA Lite. W systemach
Windows produkt ISA Lite podejmie pr�b� otworzenia pliku zasob�w za pomoc�
domy�lnej przegl�darki systemu. W systemach Linux produkt ISA Lite podejmie
pr�b� otworzenia pliku zasob�w za pomoc� przegl�darki Firefox, dlatego
niezb�dne jest zainstalowanie przegl�darki Firefox i umieszczenie jej w
zmiennej �rodowiskowej PATH. 

Znane problemy
----------------------------------
Nie nale�y instalowa� produktu ISA Lite na platformach Solaris w katalogu
zawieraj�cym bia�e znaki, w tym spacje. 

Nie nale�y instalowa� produktu ISA Lite na platformach Windows w katalogu
zawieraj�cym znaki kropki (�.�).
