# (C) COPYRIGHT International Business Machines Corp., 2007
# Todos os direitos reservados * Materiais licenciados - Propriedade da IBM

-------------------------------------------------------------
Ferramenta IBM Support Assistant Lite
------------------------------------------------------------- 

Descri��o
---------

A Ferramenta IBM Support Assistant Lite faculta recolhas autom�ticas de dados
para produtos IBM. A ferramenta est� pr�-configurada para localizar dados de
diagn�stico importantes no sistema inform�tico do utilizador e copi�-los para um ficheiro
de colector. Um exemplo de dados de diagn�stico � um ficheiro de registo gerado pelo
produto IBM do utilizador que cont�m um hist�rico detalhado dos eventos ocorridos durante
a utiliza��o do produto. Este ficheiro pode ser �til para determinar a natureza e causa
de um problema de software.
Outros exemplos de dados de diagn�stico incluem ficheiros de inicializa��o, ficheiros de
configura��o, vers�o do sistema operativo, espa�o em disco e liga��es de rede. A
ferramenta pode ser executada em modo IUG ou num modo de consola de linha de comandos. O
modo de consola faculta ao utilizador um controlo de linha de comandos dos scripts das
recolhas da ferramenta IBM Support Assistant Lite. Esta ferramenta inclui v�rios
componentes que assistem o utilizador na sua interac��o em modo de consola, incluindo um
componente que permite gravar as respostas da sess�o em modo de consola num ficheiro e,
posteriormente, utilizar o ficheiro para levar a cabo outras execu��es de um script da
mesma recolha. 

Instala��o e utiliza��o da ferramenta
-------------------------------------
Em muitos casos, a seguinte sequ�ncia de passos permite que o utilizador comece a
utilizar e executar esta ferramenta. Se encontrar problemas, ou caso pretenda mais
informa��es sobre qualquer um destes passos, pode consultar as sec��es abaixo que
se seguem a esta. 

1.	Instalar a ferramenta extraindo os ficheiros do ficheiro de arquivos que gerou e
   transferiu do sistema do Workbench.
 - Extraia a ferramenta para qualquer direct�rio que pretender.
 - Consulte as sec��es abaixo para obter detalhes sobre como executar as extrac��es. 

2.	Executar a ferramenta no modo IUG ou no modo de consola de linha de comandos. 
- Siga o procedimento descrito em seguida para configurar a vari�vel de ambiente JAVA_HOME. 
  Depois de ter feito isto, poder� ent�o executar o script de inicializa��o.
- Ap�s ter iniciado a ferramenta, siga as instru��es dadas abaixo para interagir com a
  ferramenta � medida que esta executa uma recolha. 

Instalar a ferramenta
---------------------
Em todos os casos, a instala��o da ferramenta IBM Support Assistant Lite consiste
simplesmente na extrac��o de ficheiros do ficheiro .zip arquivado, o qual o utilizador
gerou e transferiu para o sistema do Workbench. Os ficheiros podem ser extra�dos para
qualquer localiza��o do sistema de ficheiros que escolher no sistema onde vai executar
a ferramenta. Esta ac��o ir� criar no direct�rio de destino o subdirect�rio
ISALite. 


Utiliza��o da ferramenta
------------------------
Definir a vari�vel de ambiente JAVA_HOME Independentemente de se vai utilizar a ferramenta
IBM Support Assistant Lite no modo IUG ou no modo de consola de linha de comandos, utilize
o mesmo procedimento para inici�-la: invoque o script de inicializa��o apropriado a partir
da linha de comandos. No caso de um sistema Windows, estes scripts de arranque s�o ficheiros
batch. Para os outros ambientes, s�o scripts da shell. 

Uma vez que a ferramenta � implementada numa aplica��o Java, � necess�rio que o Java se
encontre no sistema antes da ferramenta ser iniciada. Se Java n�o estiver dispon�vel no PATH, ter� de definir manualmente a vari�vel de ambiente JAVA_HOME. A ferramenta IBM Support Assistant Lite requer um JRE no n�vel 1.4.2
ou superior (1.5 ou superior no Windows 7 64 bits), por isso, � necess�rio certificar-se
de que o JRE adequado est� instalado no sistema onde a ferramenta ser� executada. Se
estiver, ent�o vai ter de emitir um comando espec�fico do sistema operativo para definir
a vari�vel de JAVA_HOME com o caminho desse JRE. O Microsoft JVM/JDK e o gij (GNU libgcj)
n�o s�o suportados. 

Por exemplo, caso tenha jre1.4.2 instalado em
c:\jre1.4.2 numa plataforma Windows, deve definir JAVA_HOME utilizando o seguinte comando:

SET JAVA_HOME=c:\jre1.4.2
NOTA: N�o utilize plicas no valor do comando SET, mesmo que o valor possua espa�os em branco.

Numa plataforma Linux, AIX, Solaris ou iSeries, caso tenha o JRE instalado em
/opt/jre142, deve definir JAVA_HOME utilizando o seguinte comando:

export JAVA_HOME=/opt/jre142


Iniciar a ferramenta em modo IUG Swing
--------------------------------------
Ser� necess�rio lan�ar o seguinte script de inicializa��o: 

- Para o ambiente Windows, o script � o runISALite.bat e encontra-se no direct�rio \ISALite.
- Para os ambientes Linux, AIX, HP-UX e Solaris, o script � o runISALite.sh e encontra-se
  no direct�rio \ISALite.
Certifique-se de que o script runISALite.sh tem permiss�o de execu��o; pode utilizar o
comando seguinte para atribuir a permiss�o de execu��o ao ficheiro: chmod 755 runISALite.sh 

O modo IUG n�o � suportado nos ambientes iSeries e zSeries: consulte a sec��o
imediatamente a seguir a esta para informa��es sobre como iniciar esta ferramenta em modo
de consola de linha de comandos em iSeries e zSeries. 

Iniciar a ferramenta em modo de consola de linha de comandos
------------------------------------------------------------
Se n�o estiver dispon�vel uma IUG, a ferramenta deve iniciar-se no modo de linha de
comandos automaticamente. Se pretender utilizar o modo de consola mesmo que esteja
dispon�vel uma IUG, especifique "-console" na linha de comandos. Em alguns casos, n�o
ser� poss�vel determinar que uma IUG n�o est� dispon�vel e a ferramenta n�o ser�
iniciada. Nesses casos, ser� necess�rio reiniciar a ferramenta utilizando "-console". 

Os ficheiros s�o gravados no direct�rio de instala��o
-----------------------------------------------------
Por predefini��o, o direct�rio de  instala��o ISA Lite � utilizado para armazenar
ficheiros criados durante a execu��o. Em alguns sistemas, o direct�rio de instala��o do
ISA Lite, ser� apenas de leitura. Neste caso, utilize o par�metro -useHome. Este par�metro ir�
fazer com que os ficheiros tempor�rios sejam gravados no direct�rio tempor�rio do sistema
e os ficheiros persistentes sejam gravados no direct�rio inicial do utilizador. 

Interagir com a ferramenta
--------------------------
Quer no modo IUG, quer no modo de consola de linha de comandos, ser-lhe-� pedido que
configure v�rios campos como o nome do ficheiro zip de recolha de dados ou qualquer
outra informa��o espec�fica do produto. Ap�s efectuar estas configura��es, seleccione a
op��o de problema e a recolha de dados � executada.


Quando o IBM Support Assistant Lite � executado em modo de texto, n�o existem listas de
selec��o ou campos de registos para o utilizador introduzir dados. Em vez disso, as op��es
dispon�veis s�o apresentadas em listas numeradas e o utilizador introduz o n�mero da selec��o
e, de seguida, carrega na tecla Enter. Os campos de entrada de dados s�o transformados em pedidos de informa��es nos quais o utilizador introduz a resposta e, de seguida, prime Enter. Ap�s a conclus�o da recolha de dados, a sa�da de dados � outro ficheiro ZIP
que pode ser manualmente transferido novamente para a m�quina na qual o Workbench do IBM
Support Assistant est� instalado. A partir dessa m�quina, o ficheiro ZIP pode ser enviado
para o Suporte IBM ou examinado localmente, tal como outras recolhas executadas no
Workbench do IBM Support Assistant.


Para a ferramenta de recolha, escreva quit no modo de texto, ou fa�a clique no bot�o Sair no modo IUG. 

A ferramenta ir� pedir os nomes dos ficheiros. Em plataformas Unix, a utiliza��o de "~" como a designa��o do direct�rio HOME do utilizador n�o � suportado. Se for utilizado um "~",
ser� referenciado um sub-direct�rio sob o direct�rio de trabalho actual pelo nome de "~". 

*NOTA: Leia o manual de utiliza��o do IBM Support Assistant para obter informa��es mais detalhadas. 

Determinar informa��es sobre a vers�o
------------------------------------
Por predefini��o, a vers�o da ferramenta (e os v�rios sub-componentes) est� impressa na
consola a partir da qual foi lan�ada. Ao executar no modo IUG, tamb�m � poss�vel
localizar a informa��o sobre a vers�o utilizando a op��o do menu Ajuda->Acerca de. Se Java n�o estiver dispon�vel, ou a aplica��o Java n�o conseguir ser iniciada, tamb�m pode obter a vers�o da ferramenta executando os scripts de arranque com a op��o "-version". 

*NOTA: ao utilizar a op��o "-version", os scripts de lan�amento ir�o imprimir a
informa��o da vers�o sem invocar realmente a ferramenta. 

Visualizar o ficheiro de invent�rio
-----------------------------------
O ISA Lite pode recolher informa��o sobre o invent�rio do sistema actual. Os dados de
sa�da num ficheiro de invent�rio (inventory.xml) s�o melhor visualizados num navegador da
web. Se o ficheiro de invent�rio estiver presente, pode ser visualizado na op��o do menu
Ficheiro-->Ver na IUG do ISA Lite. No Windows, o ISA Lite ir� tentar abrir o ficheiro de
invent�rio utilizando o navegador predefinido do sistema. No Linux, o ISA Lite tenta
abrir o ficheiro de invent�rio utilizando um navegador Firefox, por conseguinte, o
Firefox tem de estar instalado e presente em PATH (caminho). 

Problemas conhecidos
--------------------
A instala��o do ISA Lite n�o deve ser realizada num direct�rio que inclua caracteres de
espa�o em branco, incluindo espa�os nas plataformas Solaris. 

a A instala��o do ISA Lite n�o dever� ser realizada num direct�rio que inclua o car�cter
'.' em plataformas Windows. 
