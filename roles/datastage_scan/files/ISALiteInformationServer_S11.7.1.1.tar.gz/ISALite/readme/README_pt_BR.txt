# (C) COPYRIGHT International Business Machines Corp., 2007
# Todos os Direitos Reservados * Materiais Licenciados - Propriedade da IBM

-------------------------------------------------------------
Ferramenta IBM Support Assistant Lite
-------------------------------------------------------------

Descri��o
---------------

A Ferramenta IBM Support Assistant Lite fornece coleta autom�tica de dados para produtos IBM. A ferramenta � pr�-configurada para localizar importantes
dados de diagn�stico em seu sistema de computador e copi�-los para um arquivo do Coletor. Um exemplo de dados de diagn�stico � um arquivo de log gerado por seu produto IBM
que cont�m um hist�rico detalhado de eventos que ocorrem durante o funcionamento do produto. Este arquivo pode ser �til na determina��o da natureza e causa de um problema de software.
Outros exemplos de dados de diagn�stico incluem arquivos de inicializa��o, arquivos de configura��o, vers�o do sistema operacional, espa�o em disco e conex�es de rede.
A ferramenta pode ser executada no modo GUI ou no modo de console da linha de comandos.
O modo de console fornece controle da linha de comandos dos scripts de coleta do IBM
Support Assistant Lite. A ferramenta inclui v�rios recursos que ir�o ajud�-lo ao
interagir com ela no modo de console, incluindo um que permite a grava��o das respostas de uma
sess�o no modo de console em um arquivo e, em seguida, o uso do arquivo para direcionar execu��es subsequentes do
mesmo script de coleta.

Instala��o e Uso da Ferramenta
------------------------------
Na maioria dos casos, a sequ�ncia de etapas a seguir o ajudar� a instalar e executar a ferramenta. Se encontrar problemas, ou se quiser
mais informa��es sobre alguma das etapas, consulte as se��es subsequentes a esta.

1.	Instale a ferramenta extraindo os arquivos do archive gerado e transferido do sistema Workbench.
 - Extraia a ferramenta em qualquer diret�rio escolhido.
 - Consulte as se��es a seguir para obter detalhes de como executar as extra��es.

2.	Execute a ferramenta no modo GUI ou no modo de console da linha de comandos.
 - Siga o procedimento descrito abaixo para configurar a vari�vel de ambiente JAVA_HOME. Depois de fazer
isso, � poss�vel executar o script de ativa��o. - Depois de iniciar a ferramenta, siga as instru��es abaixo para interagir com ela durante a execu��o de uma coleta.

Instalando a Ferramenta
-----------------------
Em todos os casos, a instala��o da ferramenta IBM Support Assistant Lite � simplesmente uma quest�o de extrair os arquivos do arquivo .zip arquivado
gerado e transferido do sistema Workbench. Os arquivos podem ser extra�dos em qualquer local do sistema de arquivos escolhido
no sistema em que a ferramenta ser� executada. 
Isso criar� um subdiret�rio ISALite no diret�rio de destino.


Uso da Ferramenta
-----------------
Configurando a Vari�vel de Ambiente JAVA_HOME
Independentemente de voc� usar a ferramenta IBM Support Assistant Lite no modo GUI ou no modo de console da linha de comandos, o mesmo
procedimento ser� usado para inici�-la: voc� chamar� o script de ativa��o apropriado a partir de uma linha de comandos. No caso de sistemas Windows, esses scripts de ativa��o ser�o
arquivos em lote. Para outros ambientes, eles ser�o shell scripts.

Como a ferramenta � implementada como um aplicativo Java, � necess�rio localizar Java para que a ferramenta possa ser iniciada. Se Java n�o estiver dispon�vel no PATH, a vari�vel de ambiente JAVA_HOME precisar� ser configurada
manualmente. A ferramenta IBM Support Assistant Lite requer um JRE no n�vel 1.4.2 ou superior
(1.5 ou superior no Windows 7 de 64 bits), portanto, � necess�rio certificar-se, antes, de que haja um JRE adequado instalado
no sistema em que a ferramenta ser� executada. Se houver, ser� necess�rio emitir um
comando espec�fico do sistema operacional para configurar a vari�vel JAVA_HOME para que aponte para esse JRE.
O Microsoft JVM/JDK e gij (GNU libgcj) n�o s�o suportados.

Por exemplo, se jre1.4.2 estiver instalado em uma plataforma Windows em
c:\jre1.4.2, JAVA_HOME ser� configurada usando o seguinte comando:

SET JAVA_HOME=c:\jre1.4.2
NOTA: N�o use aspas no valor do comando SET, mesmo que seu valor contenha caracteres de espa�o em branco.

Em uma plataforma Linux, AIX, Solaris ou iSeries, se o JRE estiver instalado em
/opt/jre142, JAVA_HOME ser� configurada usando o seguinte comando:

export JAVA_HOME=/opt/jre142


Iniciando a Ferramenta no Modo GUI Swing
----------------------------------------
Ser� necess�rio emitir o seguinte script de ativa��o:

- No ambiente Windows, ser� o script runISALite.bat no diret�rio \ISALite da ferramenta.
- Nos ambientes Linux, AIX, HP-UX e Solaris, ser� o script runISALite.sh no diret�rio /ISALite da ferramenta. Certifique-se de que o
script runISALite.sh tenha permiss�o de execu��o; � poss�vel usar o
seguinte comando para fornecer permiss�o de execu��o ao arquivo: chmod 755 runISALite.sh

O modo GUI n�o � suportado nos ambientes iSeries e zSeries: consulte a se��o imediatamente
subsequente a esta para obter informa��es sobre como iniciar a ferramenta no modo de console da linha de comandos
no iSeries e zSeries.

Iniciando a Ferramenta no Modo de Console da Linha de Comandos
--------------------------------------------------------------
Se n�o houver uma GUI dispon�vel, a ferramenta dever� ser iniciada no modo de linha de comandos automaticamente. Se
o modo de console for desejado mesmo que haja uma GUI dispon�vel, especifique "-console" na linha de comandos.
Em algumas inst�ncias, n�o ser� poss�vel determinar que n�o h� uma GUI
dispon�vel e a ferramenta n�o ser� iniciada. Nessas inst�ncias, a ferramenta precisar� ser reiniciada
usando "-console".

Os Arquivos S�o Gravados no Diret�rio de Instala��o
---------------------------------------------------
Por padr�o, o diret�rio de instala��o ISA Lite � usado para armazenar arquivos criados durante a execu��o. Em alguns sistemas, o diret�rio de instala��o ISA Lite ser� somente leitura.
Nessa inst�ncia, use
o par�metro -useHome. Esse par�metro far� com que os arquivos tempor�rios
sejam gravados no diret�rio tempor�rio systems e os arquivos persistentes gravados no diret�rio inicial do usu�rio.
	
Interagindo com a Ferramenta
----------------------------
Para os dois modos, GUI e de console da linha de comandos, ser� solicitada a configura��o de v�rios campos, como o nome do arquivo zip de coleta de dados, al�m de
outras informa��es espec�ficas do produto. Depois disso, voc� seleciona a op��o do problema e a coleta de dados � desempenhada.

Quando o IBM Support Assistant Lite � executado no modo de texto, n�o h� listas de sele��o ou campos de entrada para entrada do usu�rio.
Em vez disso, as op��es dispon�veis s�o apresentadas como listas numeradas
				e voc� digita o n�mero de sua sele��o seguido pela tecla Enter. Os campos de entrada s�o transformados
				em prompts, nos quais voc� digita sua resposta e pressiona Enter. Quando a coleta de dados estiver conclu�da,
				a sa�da ser� outro arquivo ZIP que pode ser manualmente transferida de volta para a m�quina na qual o IBM Support
				Assistant Workbench est� instalado. De l�, o arquivo ZIP de sa�da pode ser enviado para o Suporte IBM ou examinado
				localmente, da mesma forma que com outras coletas desempenhadas no IBM Support Assistant Workbench.

Para parar a ferramenta coletora, digite quit no modo de texto, ou clique no bot�o Sair no modo GUI.

A ferramenta solicitar� nomes de arquivos. Em plataformas Unix,
				usar "~" como uma designa��o do diret�rio HOME do usu�rio n�o �
				suportado. Se um "~" for usado, um subdiret�rio com o nome de "~"
    ser� referenciado no	diret�rio ativo presente.
*NOTA: Leia o guia do usu�rio do IBM Support Assistant para obter detalhes adicionais.

Determinando Informa��es de Vers�o
----------------------------------
Por padr�o, a vers�o da ferramenta (e seus v�rios subcomponentes) � impressa no console a partir do qual ela foi
ativada.  Ao executar no modo GUI, as informa��es de vers�o tamb�m podem ser localizadas usando-se a op��o de menu Ajuda->Sobre.
Se Java n�o estiver dispon�vel, ou o aplicativo Java n�o puder ser iniciado, a vers�o da ferramenta tamb�m poder� ser obtida
executando-se os scripts de ativa��o com a op��o "-version".

*NOTA: Ao usar a op��o "-version", os scripts de ativa��o imprimir�o as informa��es de vers�o sem realmente
chamar a ferramenta.

Visualizando o Arquivo de Invent�rio
------------------------------------
O ISA Lite pode coletar informa��es sobre o invent�rio do sistema atual. A sa�da � um arquivo de invent�rio (inventory.xml), melhor visualizado com um navegador da Web.
Se o arquivo de invent�rio estiver presente, ele poder� ser visualizado a partir da op��o de menu Arquivo-->Visualizar Invent�rio na GUI do ISA Lite. No Windows, o ISA Lite tentar� abrir o arquivo de invent�rio
usando o navegador padr�o do sistema. No Linux, o ISA Lite tentar� abrir o arquivo de invent�rio usando o navegador firefox, portanto, o firefox precisa ser instalado e estar presente no PATH.

Problemas Conhecidos
----------------------------------
A instala��o do ISA Lite n�o deve ser feita em um diret�rio que inclua caracteres de espa�o em branco, incluindo
espa�os em plataformas Solaris.

A instala��o do ISA Lite n�o deve ser feita em um diret�rio que inclua caracteres de ponto '.' em plataformas Windows.
