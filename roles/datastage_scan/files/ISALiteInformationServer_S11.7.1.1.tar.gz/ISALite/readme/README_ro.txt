# (C) COPYRIGHT International Business Machines Corp., 2007
# Toate drepturile rezervate * Materiale licen�iate - Proprietatea IBM

-------------------------------------------------------------
IBM Support Assistant Lite Tool
-------------------------------------------------------------

Descriere
---------------

Unealta IBM Support Assistant Lite furnizeaz� colecatrea automat� a datelor pentru produsele IBM.
Unealta este preconfigurat� pentru a localiza date importante de diagnostic din sistem �i a le copia �ntr-un fi�ier colector. Un exemplu de date de diagnostic este un fi�ier istoric generat de produsul IBM care con�ine un istoric detaliat al evenimentelor care au loc �n timpul oper�rii produsului. Un asemenea fi�ier poate fi util la determinarea naturii cauzei unei probleme software.
Alte exemple de date de diagnostic includ fi�iere de ini�ializare, fi�iere de configurare, versiunea sistemului de operare, spa�iul pe disc �i conexiunile la re�ea.
Unealta se poate rula �n mod GUI sau �ntr-un mod de consol� linie de comand�.
Modul consol� v� furnizeaz� control linie de comand� pentru scripturile de colectare
IBM Support Assistant Lite.  Unealta include mai multe caracteristici pentru a v�
asista c�nd interac�iona�i cu aceasta �n modul consol�, inclusiv una care v� permite
s� v� �nregistra�i r�spunsurile dintr-o sesiune �n mod consol� �ntr-un fi�ier �i
apoi s� utiliza�i fi�ierul pentru a conduce execu�ii urm�toare ale aceluia�i script
de colectare.

Instalare �i utilizare unealt�
------------------------------
�n majoritatea cazurilor, urm�toarea secven�� de pa�i v� va preg�ti pentru rulare cu unealta.
Dac� �nt�mpina�i probleme sau dac� a�i dori informa�ii suplimentare despre oricare dintre ace�ti pa�i, pute�i consulta sec�iunile de mai jos care o urmeaz� pe aceasta.  1.	Instala�i unealta extr�g�nd fi�ierele din fi�ierul arhiv� pe care l-a�i geenrat �i transferat din sistemul banc de lucru.
 - Extrage�i unealta �n orice director pe care �l alege�i dumneavoastr�.
 - Vede�i sec�iunile de mai jos pentru detalii privind modul de executare al extragerilor.  2.	Rula�i unealta fie �n modul GUI fie �n modul consol� linie de comand�. 
 - Urma�i procedura descris� mai jos pentru setarea variabilei de mediu JAVA_HOME. O dat� ce a�i f�cut aceasta, pute�i apoi executa lansarea script-ului.
 - O dat� ce a�i pornit unealta, urma�i instruc�iunile de mai jos pentru a interac�iona cu aceasta �n timp ce execut� colectarea.

Instalarea uneltei
--------------------
�n toate cazurile, instalarea uneltei IBM Support Assistant Lite este pur �i simplu o problem� de extragere a fi�ierelor  din fi�ierul arhivat .zip pe care l-a�i generat �i transferat din sistemul bancului de lucru. Fi�ierele se pot extrage �n orice loca�ie de sistem de fi�ier pe care o alege�i dumneavoastr� pe sistemul pe care ve�i rula unealta. 
Aceasta va crea un subdirector ISALite sub directorul dumneavoastr� vizat.

Utilizare unealt�
-----------------
Setarea variabilei de mediu JAVA_HOME
Indiferent dac� ve�i utiliza unealta IBM Support Assistant Lite �n mod GUI sau �n mod consol� linie de comand�, utiliza�i aceea�i procedur� pentru a o porni: invoca�i script-ul de lansare corespunz�tor dintr-o linie de comand�.  �n cazul unui sistem Windows, aceste script-uri de lansare sunt fi�iere batch.  Pentru celelalte medii, acestea sunt script-uri shell.  Din moment ce unealta este implementat� ca o aplica�ie Java, este necesar ca Java s� poat� fi localizat �nainte ca unealta s� poat� s� porneasc�. Dac� Java nu este disponibil pe CALE, va trebui s� seta�i manual variabila de mediu JAVA_HOME.
Unealta IBM Support Assistant Lite solicit� un JRE la nivelul 1.4.2 sau mai mare (1.5 sau mai mare pe Windows 7, 64 de bi�i),
astfel �nc�t trebuie mai �nt�i s� v� asigura�i c� un JRE potrivit este instalat pe
sistemul pe care va rula unealta. Dac� este, atunci trebui es� emite�i o comand�
specific� sistemului de operare pentru a seta variabila JAVA_HOME pentru a ar�ta
c�tre acest JRE. Nu sunt suportate Microsoft JVM/JDK �i gij (GNU libgcj).
De exemplu, dac� pe o platform� Windows ave�i jre1.4.2 instalat la
c:\jre1.4.2, ve�i seta JAVA_HOME folosind urm�toarea comand�:

SET JAVA_HOME=c:\jre1.4.2
NOT�: Nu folosi�i ghilimele �n valoarea comenzii SET, chiar dac� valoarea are caractere de spa�iu.
Pe o platform� Linux, AIX, Solaris sau iSeries, dac� ave�i JRE instalat �n
/opt/jre142, ve�i seta JAVA_HOME folosind urm�toarea comand�:

export JAVA_HOME=/opt/jre142


Pornirea uneltei �n modul Swing GUI
-----------------------------------
Va trebui s� rula�i urm�torul script de lansare:

- Pentru mediul Windows, se va rula scriptul runISALite.bat din directorul uneltei \ISALite.
- Pentru mediile Linux, AIX, HP-UX �i Solaris, va fi script-ul runISALite.sh din directorul /ISALite al uneltei. 
Asigura�i-v� c� scriptul runISALite.sh are permisiunea de executare; pute�i utiliza
urm�toarea comand� pentru a da permisiunea execut�rii fi�ierului: chmod 755
runISALite.sh

Modul GUI nu este suportat pe mediile iSeries �i zSeries: vede�i
sec�iunea imediat urm�toare acesteia pentru informa�ii despre modul de pornire a
uneltei �n modul consol� linie de comand� pe iSeries �i zSeries.

Pornirea uneltei �n mod consol� linie de comand�
-----------------------------------------------
Dac� nu este disponibil� o interfa�� grafic� (GUI), unealta va porni automat �n modul linie
de comand�. Dac� se dore�te modul consol� chiar �i c�nd este disponibil� o interfa��
grafic�, specifica�i "-console" �n linia de comand�.
�n unele cazuri, nu va fi posibil s� se determine dac� o interfa�� grafic� este sau
nu disponibil�, iar unealta nu va porni. �n aceste instan�e, unealta fa trebui
repornit� folosind "-console".

Fi�ierele sunt scrise �n directorul de instalare
------------------------------------------------
Implicit, directorul de instalare  ISA Lite este folosit pentru stocarea fi�ierelor create �n timpul execu�iei.
Pe unele sisteme, directorul de instalare ISA Lite va fi disponibil doar pentru citire. �n acest caz, folosi�i parametrul -useHome.  
Acest parametru va face ca fi�ierele temporare s� fie scrise �n directorul temporar
al sistemului �i fi�ierele persistente �n directorul home al utilizatorului.


Interac�iunea cu unealta
---------------------------
Pentru ambele moduri, GUI �i consol� linie de comand� vi se va cere s� seta�i mai multe c�mpuri, cum ar fi numele
fi�ierului ZIP de ie�ire al colec�iei de date �i orice alt� informa�ie specific�
produsului.
Dup� aceasta selecta�i op�iunea problemei �i este realizat� colectarea de date.

C�nd IBM Support Assistant Lite ruleaz� �n mod text, nu exist� liste de select�ri sau c�mpuri de intrare pentru completare de c�tre utilizator.
�n schimb, alegerile disponibile sunt prezentate ca liste numerotate �i
				introduce�i num�rul selec�iei urmat de tasta Enter. C�mpurile de completat sunt transformate �n
				prompt-uri la care introduce�i r�spunsul �i ap�sa�i Enter. C�nd colectarea de date este finalizat�,
    ie�irea este alt fi�ier ZIP care poate fi transferat manual �napoi pe ma�ina pe care este instalat IBM
    Support Assistant Workbench. De acolo, fi�ierul ZIP de ie�ire poate fi trimis la IBM Support sau examinat
				local, la fel ca �n cazul celorlalte colect�ri realizate �n IBM Support Assistant Workbench.

Pentru a opri unealta de colectare, tasta�i renun�are �n mod text sau ap�sa�i butonul Quit �n modul GUI.
Unealta va afi�a un prompt pentru numele de fi�iere. Pe platformele Unix, nu este
suportat� folosirea "~" pentru desemnearea directorului HOME al utilizatorului.
Dac� este folosit "~", va fi referit un subdirector de sub directorul de lucru curent cu numele "~".
*NOT�: V� rug�m s� citi�i ghidul utilizatorului IBM Support Assistant pentru detalii suplimentare.

Determinarea informa�iilor de versiune
--------------------------------------
Implicit, versiunea uneltei (�i a diverselor sale componente) este tip�rit� la consola de pe care a fost lansat�.
C�nd rula�i �n modul GUI, informa�iile de versiune pot fi g�site folosind op�iunea de meniu Help->About.
Dac� Java nu este disponibil sau aplica�ia Java nu poate porni, pute�i s� ob�ine�i
versiunea uneltei prin rularea scripturilor cu op�iunea "-version".
*NOT�: C�nd folosi�i op�iunea "-version", scripturile de lansare vor tip�ri
informa�iile de versiune, f�r� s� lanseze de fapt unealta.

Vizualizarea fi�ierului Inventory
---------------------------------
ISA Lite poate colecta informa�ii de inventar de pe sistemul curent. Ie�irea este un fi�ier de inventar (inventory.xml), care se vizulizeaz� cel mai bine cu un browser Web.
Dac� fi�ierul de inventar este prezent, el poate fi vizualizat din op�iunea de meniu File-->View Inventory de pe interfa�a grafic� ISA Lite. 
Pe Windows, ISA Lite va �ncerca s� deschid� fi�ierul inventar folosind browser-ul implicit al sistemului.
Pe Linux, ISA Lite �ncearc� s� deschid� fi�ierul de inventar folosind browser-ul
Firefox, de aceea Firefox trebuie s� fi instalat �i s� fie prezent �n PATH.

Probleme cunsocute
----------------------------------
Instalarea pentru ISA Lite nu trebuie f�cut� �ntr-un director care include caractere spa�iu pe platforma Solaris.
Instalarea pentru ISA Lite nu trebuie f�cut� �ntr-un director care include caractere punct '.' pe platformele Windows.
