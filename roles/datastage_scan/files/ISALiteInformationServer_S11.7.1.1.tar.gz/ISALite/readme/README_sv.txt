# (C) COPYRIGHT International Business Machines Corp., 2007
# All Rights Reserved * Licensed Materials - Property of IBM

-------------------------------------------------------------
Verktyget IBM Support Assistant Lite
-------------------------------------------------------------

Beskrivning
---------------

Verktyget IBM Support Assistant Lite tillhandah�ller automatisk
datainsamling f�r IBM-produkter. Verktyget �r f�rkonfigurerat f�r
att s�ka upp viktiga fels�kningsdata p� datorn och kopiera dem
till en insamlingsfil. Exempel p� fels�kningsdata �r en loggfil
som genererats av IBM-produkten och som inneh�ller en detaljerad
historik �ver h�ndelser under driften av produkten. En s�dan fil
kan vara till hj�lp vid s�kandet efter orsaken till programfelet.
Andra exempel p� fels�kningsinformation �r initieringsfiler,
konfigurationsfiler samt information om operativsystemversion,
diskutrymme och n�tverksanslutningar. Verktyget kan k�ras i ett
grafiskt gr�nssnitt eller fr�n en kommandokonsol.
Konsoll�get inneh�ller kommandoradskontroller f�r IBM Support
Assistant Lite-insamlingsskript. Verktyget inneh�ller flera
funktioner i konsoll�get. Du kan t.ex. registrera svaren fr�n en
konsolsession i en fil och sedan anv�nda filen n�r du k�r samma
insamlingsskript n�sta g�ng. Installation och anv�ndning av verktyget
----------------------------------------
I de flesta fall installerar du och k�r verktyget med hj�lp av
nedanst�ende steg. Om du st�ter p� problem, eller om du vill ha mer
information om n�got av stegen kan du l�sa avsnitten nedanf�r.

1.	Installera verktyget genom att extrahera filer fr�n arkivfilen
   som skapades och �verf�rdes fr�n Workbench-systemet.
   - Extrahera verktyget till valfri katalog.
   - Anvisningar om hur du extraherar filerna finns nedan.

2.	K�r verktyget i det grafiska gr�nssnittet eller i kommandol�ge. 
   - F�lj proceduren som beskrivs nedan och ange milj�variabeln
     JAVA_HOME.
     N�r du har gjort det kan du k�ra startskriptet.
   - N�r du har startat verktyget f�ljer du anvisningarna nedan
     om hur du interagerar med det under insamlingen. Installera verktyget
--------------------
Installationen av IBM Support Assistant Lite best�r i att extrahera
filerna i den arkiverade ZIP-filen som skapades och �verf�rdes
fr�n Workbench-systemet. Filerna kan extraheras till valfri plats
i systemet d�r verktyget ska k�ras. Underkatalogen ISALite skapas
i m�lkatalogen. Anv�nda verktyget
-----------------
Ange milj�variabeln JAVA_HOME
Oavsett om du anv�nder IBM Support Assistant Lite i det grafiska
gr�nssnittet eller i kommandokonsolen anv�nder du samma procedur
f�r att starta det. Du anropar l�mpligt startskript fr�n en
kommandorad. I Windows �r startskripten batch-filer. I andra
milj�er �r de skalskript. Eftersom verktyget har implementerats
som en Java-till�mpning m�ste Java finnas i s�kv�gen innan
verktyget kan startas.
Om Java inte finns i PATH m�ste du ange JAVA_HOME-milj�variabeln
manuellt. IBM Support Assistant Lite kr�ver JRE 1.4.2 eller
senare (1.5 eller senare i Windows 7, 64-bitars) s� kontrollera
f�rst att en passande JRE-version har installerats i det system
verktyget ska anv�ndas. Om det har det
m�ste du anv�nda ett operativsystemspecifikt kommando till att
ange JAVA_HOME-variabeln s� att den pekar p� den JRE-versionen.
Microsoft JVM/JDK och gij (GNU libgcj) st�ds inte.

Om du till exempel har jre1.4.2 installerat p�
c:\jrel.4.2 i ett Windows-system kan du
konfigurera JAVA_HOME med f�ljande kommando:

SET JAVA_HOME=c:\jre1.4.2
Anm. Anv�nd inte citattecken i v�rdet f�r
SET-kommandot, �ven om v�rdet har blanktecken.

Om du har JRE installerad p� /opt/jre142 p�
Linux, AIX, Solaris och iSeries kan du ange
JAVA_HOME med f�ljande kommando:

export JAVA_HOME=/opt/jre142


Starta verktyget i Swing GUI-l�ge
------------------------------------
K�r f�ljande startskript:

- Windows: Skriptet runISALite.bat i katalogen \ISALite.
- Linux, AIX, HP-UX och Solaris: Skriptet runISALite.sh i
katalogen /ISALite. Kontrollera att skriptet runISALite.sh har
k�rbeh�righet. Du kan anv�nda f�ljande kommando till att ge
filen k�rbeh�righet: chmod 755 runISALite.sh

Det finns inget grafiskt gr�nssnitt i iSeries eller zSeries.
Mer information om hur du startar verktyget i konsoll�ge i
iSeries och zSeries finns i n�sta avsnitt.

Starta verktyget i konsoll�get
-----------------------------------------------
Om det inte finns n�got grafiskt anv�ndargr�nssnitt tillg�ngligt
startar verktyget automatiskt i konsoll�get. Om verktyget ska
startas i konsoll�ge �ven n�r ett grafiskt anv�ndargr�nssnitt
�r tillg�ngligt, l�gger du till parametern "-console" p�
kommandoraden. I vissa fall �r det inte m�jligt att fastst�lla
att ett grafiskt anv�ndargr�nssnitt inte �r tillg�ngligt och
verktyget startar inte. I dessa fall m�ste verktyget startas om
med parametern "-console".

Filerna skrivs till installationskatalogen
-----------------------------------------------
Som standard anv�nds ISA Lites installationskatalog f�r att
lagra filer som skapas under k�rningen. P� vissa system �r
ISA Lites installationskatalog skrivskyddad. I s� fall anger du
parametern - useHome. Den h�r parametern g�r att tillf�lliga
filer skrivs till systemets tempor�ra katalog och best�ndiga
filer skrivs till anv�ndarens hemkatalog. 
	
Interagera med verktyget
---------------------------
B�de i gr�nssnittet och i kommandokonsolen f�r du ange v�rden i
flera f�lt, t.ex. namnet p� datainsamlingens ZIP-fil och annan
produktspecifik information. N�r det �r klart v�ljer du
felalternativ och sedan utf�rs datainsamlingen. N�r IBM Support
Assistant Lite k�rs i textl�ge visas inga vallistor eller
inmatningsf�lt f�r indata.
I st�llet visas alternativen som numrerade listor och du v�ljer
alternativ genom att skriva en siffra och trycka p� Enter.
Indataf�lt visas som uppmaningar d�r du anger ett svar och sedan
trycker p� Enter. N�r datainsamlingen �r klar samlas alla utdata
i en ZIP-fil som du kan �verf�ra manuellt till datorn d�r
IBM Support Assistant Workbench �r installerad. D�rifr�n kan
ZIP-filen skickas till IBM Support eller granskas p� plats, p�
samma s�tt som andra insamlingar som g�rs i IBM Support Assistant
Workbench.
Om du vill stoppa insamlingen skriver du "quit" i textl�ge eller
klickar p� Avbryt i gr�nssnittet. Verktyget fr�gar efter filnamn. P� Unix-plattformar �r det inte m�jligt att ange
anv�ndarens hemkatalog med "~". Tecknet "~" skulle avse en
underkatalog till den aktuella arbetskatalogen med namnet "~".

*Anm. L�s anv�ndarhandboken till IBM Support Assistant om du
beh�ver mer information. Best�mma version
----------------------------------
Som standard skrivs versionen f�r verktyget (och dess olika
delprojekt) till konsolen som det startades fr�n. N�r du k�r
verktyget i det grafiska gr�nssnittet kan versionsinformationen
ocks� hittas under menyalternativet Hj�lp -> Om.
Om Java inte �r tillg�ngligt, eller Java-programmet inte kan
startas, kan du ocks� f� verktygets versionsnummer genom att
k�ra startskriptet med alternativet "-version".

*Obs! N�r du anv�nder alternativet "-version" skriver
startskriptet ut versionsinformationen utan att faktiskt
starta verktyget.

Visa inventeringsfil
----------------------
ISA Lite kan samla in inventeringsinformation i det nuvarande
systemet. Resultatet �r en inventering-fil (inventory.xml) som
visas b�st i en webbl�sare.
Om inventeringsfilen �r tillg�nglig kan den ses visas med
menyalternativet Arkiv --> Visa inventering i
anv�ndargr�nssnittet f�r ISA Lite. I Windows f�rs�ker ISA Lite
�ppna inventeringsfilen i systemets standardwebbl�sare. I Linux
f�rs�ker ISA Lite �ppna inventeringsfilen med webbl�saren Firefox.
Firefox m�ste d�rf�r vara installerat och finnas i s�kv�gen (PATH).

K�nda problem
----------------------------------
ISA Lite f�r inte installeras i en katalog vars namn inneh�ller
blankstegstecken p� Solaris-plattformar.

ISA Lite f�r inte installeras i en katalog med punkt ('.') i
namnet p� Windows-plattformar.
