#*************************************************************************
#
# Licensed Materials - Property of IBM
# IBM Support Assistant
#
# (C) Copyright IBM Corp., 2009 - 2013 All Rights Reserved
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
#************************************************************************
#
# This script is used to list the node and server topology for a WebSphere cluster or
# standalone environment.  It outputs the topology in the form of name value pairs.
#
# Usage (from the dmgr or standalone profile bin directory):
#
#       wsadmin -conntype NONE -lang jython -profile <path>\WAuJ.py -WAuJ -f ListNodes.py
#
# Sample output:
#   
#   dmgr_node              =pisaCellManager01
#   dmgr_name              =dmgr
#   dmgr_type              =DEPLOYMENT_MANAGER
#   dmgr_profile_root      =C:\IBM\WebSphere\AppServer\profiles\Dmgr01
#   dmgr_host              =pisa.bocaraton.ibm.com
#   dmgr_ip_addr           =9.22.99.56
#   dmgr_bootstrap         =9809
#   dmgr_started           =true
#   dmgr_ServerLogRoot     =C:\IBM\WebSphere\AppServer\profiles\Dmgr01/logs/dmgr
#   dmgr_traceFile         =C:\IBM\WebSphere\AppServer\profiles\Dmgr01/logs/dmgr/trace.log
#   dmgr_stdErrFile        =C:\IBM\WebSphere\AppServer\profiles\Dmgr01/logs/dmgr/native_stderr.log
#   dmgr_stdOutFile        =C:\IBM\WebSphere\AppServer\profiles\Dmgr01/logs/dmgr/native_stdout.log
#   dmgr_sysErrFile        =$(LOG_ROOT)/dmgr/SystemErr.log
#   dmgr_sysOutFile        =$(LOG_ROOT)/dmgr/SystemOut.log
#   dmgr_httpErrFile       =C:\IBM\WebSphere\AppServer\profiles\Dmgr01/logs/dmgr/http_error.log
#   dmgr_httpAccFile       =C:\IBM\WebSphere\AppServer\profiles\Dmgr01/logs/dmgr/http_access.log
#   
#   server1_node           =pisaNode01
#   server1_name           =server1
#   server1_type           =APPLICATION_SERVER
#   server1_profile_root   =C:\IBM\WebSphere\AppServer\profiles\Custom01
#   server1_host           =pisa.bocaraton.ibm.com
#   server1_ip_addr        =9.22.99.56
#   server1_bootstrap      =9810
#   server1_started        =false
#   server1_ServerLogRoot  =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server1
#   server1_traceFile      =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server1/trace.log
#   server1_stdErrFile     =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server1/native_stderr.log
#   server1_stdOutFile     =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server1/native_stdout.log
#   server1_sysErrFile     =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server1/SystemErr.log
#   server1_sysOutFile     =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server1/SystemOut.log
#   server1_httpErrFile    =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server1/http_error.log
#   server1_httpAccFile    =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server1/http_access.log
#   
#   server2_node           =torrinoNode01
#   server2_name           =server2
#   server2_type           =APPLICATION_SERVER
#   server2_profile_root   =C:\IBM\WebSphere\AppServer\profiles\Custom02
#   server2_host           =torrino.bocaraton.ibm.com
#   server2_ip_addr        =9.22.99.57
#   server2_bootstrap      =9810
#   server2_started        =true
#   server2_ServerLogRoot  =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server5
#   server2_traceFile      =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server5/trace.log
#   server2_stdErrFile     =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server5/native_stderr.log
#   server2_stdOutFile     =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server5/native_stdout.log
#   server2_sysErrFile     =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server5/SystemErr.log
#   server2_sysOutFile     =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server5/SystemOut.log
#   server2_httpErrFile    =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server5/http_error.log
#   server2_httpAccFile    =C:\IBM\WebSphere\AppServer\profiles\Custom01/logs/server5/http_access.log
#   
#   server3_node           =torrinoNode01
#   server3_name           =server3
#   server3_type           =APPLICATION_SERVER
#   server3_profile_root   =C:\IBM\WebSphere\AppServer\profiles\Custom02
#   server3_host           =torrino.bocaraton.ibm.com
#   server3_ip_addr        =9.22.99.57
#   server3_bootstrap      =9811
#   server3_started        =true
#   server3_ServerLogRoot  =C:\IBM\WebSphere\AppServer\profiles\Custom02/logs/server2
#   server3_traceFile      =C:\IBM\WebSphere\AppServer\profiles\Custom02/logs/server2/trace.log
#   server3_stdErrFile     =C:\IBM\WebSphere\AppServer\profiles\Custom02/logs/server2/native_stderr.log
#   server3_stdOutFile     =C:\IBM\WebSphere\AppServer\profiles\Custom02/logs/server2/native_stdout.log
#   server3_sysErrFile     =C:\IBM\WebSphere\AppServer\profiles\Custom02/logs/server2/SystemErr.log
#   server3_sysOutFile     =C:\IBM\WebSphere\AppServer\profiles\Custom02/logs/server2/SystemOut.log
#   server3_httpErrFile    =C:\IBM\WebSphere\AppServer\profiles\Custom02/logs/server2/http_error.log
#   server3_httpAccFile    =C:\IBM\WebSphere\AppServer\profiles\Custom02/logs/server2/http_access.log
#   
#   node1_agent_started    =false
#   node1_name             =pisaNode01
#   
#   node2_agent_started    =true
#   node2_name             =torrinoNode01
#   
#   server_count           =3
#   node_count             =2
#   is_cluster             =true
#   cluster_name           =Cluster01
#
#************************************************************************
 
import socket
import java
lineSeparator = java.lang.System.getProperty( "line.separator" )
 
#===================================================================================================#
# getHostIp
#
# This function is used to get the ip address of the specified host.
#
# Parms:
# host - host name.
#
# Returns:
# The ip address of the specified host
#
#===================================================================================================#
def getHostIp(host) :

    #return socket.gethostbyname(host)
    try:
        ip = socket.gethostbyname(host)
    except java.net.UnknownHostException:
        ip = 'IP address not available'
    return ip

#enDef

#===================================================================================================#
# getVariablebyNode
#
# This function is used to get the value of the specified WAS variable.
#
# Parms:
# varName - Name of the variable to be queried.
# node - Name of the node to use in looking up object id. (optional)
#
# Returns:
# The value of the specified WAS variable
#
#===================================================================================================#
def getVariablebyNode(varName, node) :

    paramList    = []

    # Combine parameter list
    paramList.extend(['-scope', 'Node=%s' % (node)])

    paramList.extend(['-variableName', '"%s"' % (varName)])
    param = " ".join(paramList)

    cmd = "AdminTask.showVariables('[%s]')" % (param)

    return eval(cmd)

#endDef

#===================================================================================================#
# getServerInfoMap
#
# This function will get key properties and information for the specified serverEntry
#
# Parms:
# serverEntry - server entry
# nodeName - node name
# index - index for numbering server entries
#
# Returns:
# A Map including some key properties and information of a serverEntry, 
# like node, profile root, server name, server type, host name, ip address, bootstrap port
# node agent started flag, index, clustered flag and cluster name (if clustered)
#
# For example:
#
# {
#       'node'                :  'pisaNode01',
#       'root'                :  'C:\IBM\WebSphere\AppServer\profiles\Custom01',
#       'name'                :  'server1'
#       'type'                :  'APPLICATION_SERVER'
#       'host'                :  'pisa.bocaraton.ibm.com',
#       'ip'                  :  '9.22.99.56',
#       'port'                :  '9810'
#       'started'             :  'true'
#       'index'               :  '1'
#       'clustered'           :  'true'
#       'cluster'             :  'Cluster01'
# }
#
#===================================================================================================#
def getServerInfoMap(serverEntry, serverFileLoc, nodeName, index, isNodeAgent) :

    serverInfoMap = {}

    namedEndPoints = AdminConfig.list( "NamedEndPoint" , serverEntry ).split(lineSeparator)
    for namedEndPoint in namedEndPoints:
        endPointName = AdminConfig.showAttribute(namedEndPoint, "endPointName" )
        if endPointName == 'BOOTSTRAP_ADDRESS' :
            endPoint                        = AdminConfig.showAttribute(namedEndPoint, "endPoint" )
            serverInfoMap['node']           = nodeName
            serverInfoMap['root']           = getVariablebyNode('USER_INSTALL_ROOT', nodeName)
            serverName                      = AdminConfig.showAttribute(serverEntry, "serverName" )
            serverInfoMap['name']           = serverName
            serverInfoMap['type']           = AdminConfig.showAttribute(serverEntry, "serverType" )
            host                            = AdminConfig.showAttribute(endPoint, "host" )
            serverInfoMap['host']           = host
            serverInfoMap['ip']             = getHostIp(host)
            port                            = AdminConfig.showAttribute(endPoint, "port" )
            serverInfoMap['port']           = port
            serverInfoMap['started']        = isPortActive( host, port )
            serverInfoMap['index']          = index

            if isNodeAgent == 'false' :

                # SERVER_LOG_ROOT variable
                for wasVar in AdminConfig.list( 'VariableSubstitutionEntry' ).splitlines() :
                    varname = AdminConfig.showAttribute( wasVar, 'symbolicName' )
                    if varname == 'SERVER_LOG_ROOT' :
                        value = AdminConfig.showAttribute( wasVar, 'value' )
                        configID = serverName+wasVar
                        configIDDict = WAuJ.configIdAsDict( configID )
                        sl     = configIDDict[ 'servers' ]
                        if sl == serverName :
                            ServerLogRoot = WAuJ.unravel( value, serverFileLoc )
                            serverInfoMap['ServerLogRoot']          = ServerLogRoot
                        #endIf we have the correct server
                    #endIf we have the right variable
                #endFor

                # trace file
                ts     = AdminConfig.list( 'TraceService', serverFileLoc )
                tsDict = WAuJ.showAsDict( ts ) 
                tl     = tsDict[ 'traceLog' ]
                tlDict = WAuJ.showAsDict( tl )
                log    = tlDict[ 'fileName' ]
                traceFile = WAuJ.unravel( log, serverFileLoc )
                serverInfoMap['traceFile']          = traceFile

                # stderr and stdout files
                stds     = AdminConfig.list( 'JavaProcessDef', serverFileLoc )
                stdsDict = WAuJ.showAsDict( stds ) 
                stdl     = stdsDict[ 'ioRedirect' ]
                stdlDict = WAuJ.showAsDict( stdl )
                errlog    = stdlDict[ 'stderrFilename' ]
                outlog    = stdlDict[ 'stdoutFilename' ]
                stdErrFile = WAuJ.unravel( errlog, serverFileLoc )
                stdOutFile = WAuJ.unravel( outlog, serverFileLoc )
                serverInfoMap['stdErrFile']          = stdErrFile
                serverInfoMap['stdOutFile']          = stdOutFile

                # SystemErr and SystemOut files
                errst = AdminConfig.showAttribute( serverFileLoc, 'errorStreamRedirect' )
                outst = AdminConfig.showAttribute( serverFileLoc, 'outputStreamRedirect' )
                errDict = WAuJ.showAsDict( errst ) 
                outDict = WAuJ.showAsDict( outst ) 
                errFile     = errDict[ 'fileName' ]
                outFile     = outDict[ 'fileName' ]
                # handle the apparent bug of WAS default using $() instead of ${}
                sysErrFile = WAuJ.unravel( errFile, serverFileLoc, 1, 1 )
                sysOutFile = WAuJ.unravel( outFile, serverFileLoc, 1, 1 )
                serverInfoMap['sysErrFile']          = sysErrFile
                serverInfoMap['sysOutFile']          = sysOutFile

                # http_error and http_access files
                https     = AdminConfig.list( 'HTTPAccessLoggingService', serverFileLoc )
                httpsDict = WAuJ.showAsDict( https ) 
                httpel     = httpsDict[ 'errorLog' ]
                httpal     = httpsDict[ 'accessLog' ]
                httpelDict = WAuJ.showAsDict( httpel )
                httpalDict = WAuJ.showAsDict( httpal )
                httperrlog    = httpelDict[ 'filePath' ]
                httpacclog    = httpalDict[ 'filePath' ]
                httpErrFile = WAuJ.unravel( httperrlog, serverFileLoc )
                httpAccFile = WAuJ.unravel( httpacclog, serverFileLoc )
                serverInfoMap['httpErrFile']          = httpErrFile
                serverInfoMap['httpAccFile']          = httpAccFile

            #endIf type is not NodeAgent 

            if (isCluster == 'true' and clusterMemberMap.has_key(nodeName + "-" + serverName)) :
                serverInfoMap['clustered']  = 'true'
                serverInfoMap['cluster']    = clusterMemberMap[nodeName + "-" + serverName]
            else :
                serverInfoMap['clustered']  = 'false'
                serverInfoMap['cluster']    = ''
            #endIf isCluster and cluster member
        #endIf endPointName is BOOTSTRAP_ADDRESS
    #endFor all namedEndPoints                    
    
    return serverInfoMap
    
#endDef

#===================================================================================================#
# isPortActive
#
# This function will attempt to create a socket and connect to determine if a port is active (and
# the corresponding agent is listening on it).
#
# Parms:
# host - host name.
# port - port number.
#
# Returns:
# The ip address of the specified host
#
#===================================================================================================#
def isPortActive( host, port ) :

    try :
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(( host, int(port) ))
        s.close()
        return "true"
    except :
        return "false"
    #endTry
    
#endDef

#===================================================================================================#
# printServerInfo
#
# This function print information about the server in name = value format.
#
# Parms:
# serverInfoMap - server information.
#
#===================================================================================================#
def printServerInfo( serverInfoMap ) :
    if serverInfoMap['type'] == 'DEPLOYMENT_MANAGER' :
        print
        print "dmgr_node                   =" + serverInfoMap['node']
        print "dmgr_name                   =" + serverInfoMap['name']
        print "dmgr_type                   =" + serverInfoMap['type']
        print "dmgr_profile_root           =" + serverInfoMap['root']
        print "dmgr_host                   =" + serverInfoMap['host']
        print "dmgr_ip_addr                =" + serverInfoMap['ip']
        print "dmgr_bootstrap              =" + serverInfoMap['port']
        print "dmgr_started                =" + serverInfoMap['started']
        print "dmgr_ServerLogRoot          =" + serverInfoMap['ServerLogRoot']
        print "dmgr_traceFile              =" + serverInfoMap['traceFile']
        print "dmgr_stdErrFile             =" + serverInfoMap['stdErrFile']
        print "dmgr_stdOutFile             =" + serverInfoMap['stdOutFile']
        print "dmgr_sysErrFile             =" + serverInfoMap['sysErrFile']
        print "dmgr_sysOutFile             =" + serverInfoMap['sysOutFile']
        print "dmgr_httpErrFile            =" + serverInfoMap['httpErrFile']
        print "dmgr_httpAccFile            =" + serverInfoMap['httpAccFile']
    else :
        print
        print "server%d_node                =%s" % (serverInfoMap['index'],serverInfoMap['node'])
        print "server%d_name                =%s" % (serverInfoMap['index'],serverInfoMap['name'])
        print "server%d_type                =%s" % (serverInfoMap['index'],serverInfoMap['type'])
        print "server%d_profile_root        =%s" % (serverInfoMap['index'],serverInfoMap['root'])
        print "server%d_host                =%s" % (serverInfoMap['index'],serverInfoMap['host'])
        print "server%d_ip_addr             =%s" % (serverInfoMap['index'],serverInfoMap['ip'])
        print "server%d_bootstrap           =%s" % (serverInfoMap['index'],serverInfoMap['port'])
        print "server%d_started             =%s" % (serverInfoMap['index'],serverInfoMap['started'])
        print "server%d_ServerLogRoot       =%s" % (serverInfoMap['index'],serverInfoMap['ServerLogRoot'])
        print "server%d_traceFile           =%s" % (serverInfoMap['index'],serverInfoMap['traceFile'])
        print "server%d_stdErrFile          =%s" % (serverInfoMap['index'],serverInfoMap['stdErrFile'])
        print "server%d_stdOutFile          =%s" % (serverInfoMap['index'],serverInfoMap['stdOutFile'])
        print "server%d_sysErrFile          =%s" % (serverInfoMap['index'],serverInfoMap['sysErrFile'])
        print "server%d_sysOutFile          =%s" % (serverInfoMap['index'],serverInfoMap['sysOutFile'])
        print "server%d_httpErrFile         =%s" % (serverInfoMap['index'],serverInfoMap['httpErrFile'])
        print "server%d_httpAccFile         =%s" % (serverInfoMap['index'],serverInfoMap['httpAccFile'])
    #endIf
#endDef

#===================================================================================================#
# printNodeInfo
#
# This function print information about the node in name = value format.
#
# Parms:
# serverInfoMap - server information.
#
#===================================================================================================#
def printNodeInfo( serverInfoMap ) :
    print 
    print "node%d_agent_started         =%s" % (serverInfoMap['index'],serverInfoMap['started'])
    print "node%d_name                  =%s" % (serverInfoMap['index'],serverInfoMap['node'])
#endDef

#===================================================================================================#
# printNameValueServerInfo
#
# This function print information about the servers in name,value pair format.
#
# Parms:
# allServerInfoList - server information for all servers.
# allNodeInfoList - node information for all nodes.
#
#===================================================================================================#
def printNameValueServerInfo( allServerInfoList, allNodeInfoList ) :
    for serverInfoMap in allServerInfoList :
        printServerInfo( serverInfoMap )
    #endFor
    
    for serverInfoMap in allNodeInfoList :
        printNodeInfo( serverInfoMap )
    #endFor
    
    if isCluster == "true" :
        serverCount = len(allServerInfoList) - 1
        nodeCount   = len(allNodeInfoList)
    else :
        serverCount = 1
        nodeCount   = 1
    #endIf
    
    print                           
    print "server_count                =%d" % (serverCount)
    print "node_count                  =%d" % (nodeCount)
    print "is_cluster                  =%s" % (isCluster)
    if isCluster == "true" :
        print "cluster_name                =%s" % (clusterName)
        print "is_invalid_cluster          =%s" % (invalidClusters)
	print "clusters_count              =%d" % (totalClusters)
    #endIf
        
#endDef

# ******************************************************************************** #
# ********************************** Main Section ******************************** #
# ******************************************************************************** #

isCluster = "false"
clusterName = ""
nodeNo = 1
serverNo = 1
allServerInfoList = []
allNodeInfoList = []
allNodeInfoMap = {}
clusterMemberMap = {}
clusterNodeMap = {}
invalidClusters = "false"
totalClusters=0

# create cluster member and node maps (if cluster exists)
clusters=AdminConfig.list( "ServerCluster" ).split(lineSeparator)
# IS only supports 1 cluster
totalClusters = len(clusters)
if (totalClusters  > 1) :
    invalidClusters="true"
#endIf 
for cluster in clusters :
    if ( len(cluster) > 0 ) :
        isCluster = "true"
        clusterName = AdminConfig.showAttribute( cluster, "name" )
        clusterMembers = AdminConfig.list( "ClusterMember" , cluster).split(lineSeparator)
        for clusterMember in clusterMembers:
            serverName = AdminConfig.showAttribute(clusterMember, "memberName")
            nodeName = AdminConfig.showAttribute(clusterMember, "nodeName")
            clusterMemberMap[nodeName + "-" + serverName]=clusterName
            clusterNodeMap[nodeName]=clusterName
        #endFor members in the cluster
        # only look at first cluster
        break
    #endIf cluster is not zero length
#endFor all clusters

# list all nodes and servers
nodes=AdminConfig.list( "Node" ).split(lineSeparator)
if len(nodes) == 0 :
    print "No nodes found, exit..."
    exit -1
#endIf no nodes were found

# go through each node
for node in nodes :
    nodeName = AdminConfig.showAttribute( node, "name" )
    # list all server entries
    serverEntries = AdminConfig.list( "ServerEntry" , node ).split(lineSeparator)
    for serverEntry in serverEntries :
        serverName = AdminConfig.showAttribute(serverEntry, "serverName" )
        serverType = AdminConfig.showAttribute(serverEntry, "serverType" )
        if serverType == 'DEPLOYMENT_MANAGER' :
            for serverFileLoc in AdminConfig.list( 'Server' ).splitlines() :
                nameFileLoc = AdminConfig.showAttribute( serverFileLoc, 'name' )
                TypeFileLoc = AdminConfig.showAttribute( serverFileLoc, 'serverType' )
                if nameFileLoc == serverName :
                    if TypeFileLoc == 'DEPLOYMENT_MANAGER' :
                        serverInfoMap = getServerInfoMap(serverEntry, serverFileLoc, nodeName, serverNo, 'false')
                        allServerInfoList.append(serverInfoMap)
                    #endIf Server type matches ServerEntry type - we have a match
                #endIf Server name matches ServerEntry name - we might have a match
            #endFor loop to find Server that matches ServerEntry
        elif serverType == 'APPLICATION_SERVER' :
            for serverFileLoc in AdminConfig.list( 'Server' ).splitlines() :
                nameFileLoc = AdminConfig.showAttribute( serverFileLoc, 'name' )
                TypeFileLoc = AdminConfig.showAttribute( serverFileLoc, 'serverType' )
                if nameFileLoc == serverName :
                    if TypeFileLoc == 'APPLICATION_SERVER' :
                        serverInfoMap = getServerInfoMap(serverEntry, serverFileLoc, nodeName, serverNo, 'false')
                        # if a cluster is detected, make sure server is a cluster member
                        if (isCluster == "true") :
                            if (serverInfoMap['clustered'] == 'true'):
                                allServerInfoList.append(serverInfoMap)
                                serverNo = serverNo + 1
                            #endIf server is a cluster member
                        else :
                            allServerInfoList.append(serverInfoMap)
                            serverNo = serverNo + 1
                        #endIf cluster detected
                    #endIf Server type matches ServerEntry type - we have a match
                #endIf Server name matches ServerEntry name - we might have a match
            #endFor loop to find Server that matches ServerEntry
        elif serverType == 'NODE_AGENT' :
                        if ( clusterNodeMap.has_key(nodeName) ) :
                            serverInfoMap = getServerInfoMap(serverEntry, "", nodeName, nodeNo, 'true')
                            allNodeInfoList.append(serverInfoMap)
                            allNodeInfoMap[nodeName] = serverInfoMap
                            nodeNo = nodeNo + 1
                        #endIf node is part of the cluster
        #endIf serverType is DEPLOYMENT_MANAGER or APPLICATION_SERVER or NODE_AGENT
    #endFor all serverEntries
#endFor all nodes 

printNameValueServerInfo( allServerInfoList, allNodeInfoList )
